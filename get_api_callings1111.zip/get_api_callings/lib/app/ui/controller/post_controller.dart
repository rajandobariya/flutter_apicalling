import 'dart:convert';

import 'package:get_api_callings/app/modal/post_modal.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class PostController extends GetxController {
  List<Post>? posts;

  var isDataLoading = false.obs;

  @override
  Future<void> onInit() async {
    super.onInit();
    getApi();
  }

  @override
  Future<void> onReady() async {
    super.onReady();
  }

  @override
  void onClose() {}

  getApi() async {
    try {
      isDataLoading(true);
      http.Response response = await http.get(
        Uri.tryParse('https://jsonplaceholder.typicode.com/posts')!,
      );
      if (response.statusCode == 200) {
        var result = jsonDecode(response.body) as List<dynamic>;
        posts = result.map((e) => Post.fromJson(e)).toList();
      } else {
        // Handle error
      }
    } catch (e) {
      print('Error while getting data is $e');
    } finally {
      isDataLoading(false);
    }
  }
}