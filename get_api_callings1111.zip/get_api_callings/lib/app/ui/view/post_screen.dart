import 'package:flutter/material.dart';
import 'package:get_api_callings/app/ui/controller/post_controller.dart';
import 'package:get/get.dart';

class PostScreen extends StatefulWidget {
  const PostScreen({super.key});

  @override
  State<PostScreen> createState() => _PostScreenState();
}

class _PostScreenState extends State<PostScreen> {
  PostController postController = Get.put(PostController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Post Screen',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Obx(
        () => postController.isDataLoading.value
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : ListView.builder(
                itemCount: postController.posts!.length,
                itemBuilder: (context, index) {
                  return Column(
                    children: [
                      Container(
                        margin:   EdgeInsets.only(left: 20, right: 20),
                        padding:   EdgeInsets.only(left: 20),
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CircleAvatar(
                              child: Text(postController.posts![index].id.toString()+"."+postController.posts![index].userId.toString() ),
                            ),
                            Expanded(
                              child: Column(
                                children: [
                                  Text(
                                    postController.posts![index].title!
                                        .toUpperCase(),
                                    style: const TextStyle(
                                        color: Colors.black, fontSize: 18),
                                  ),
                                  Divider(color: Colors.red,height: 2,thickness: 2),
                                  Text(
                                    postController.posts![index].body!
                                        .toUpperCase(),
                                    style: const TextStyle(
                                        color: Colors.black, fontSize: 18),
                                  ),
                                ],
                              ),
                            ),
                            // Add additional fields as needed
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      )
                    ],
                  );
                },
              ),
      ),
    );
  }
}
