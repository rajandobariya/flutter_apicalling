import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getx/counter_controller.dart';
import 'package:getx/screen_one.dart';

// class HomeScreen extends StatelessWidget {
//   const HomeScreen({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Home Screen'),
//       ),
//       body: Column(
//         children: [
//           Card(
//             child: ListTile(
//               title: Text('Getx Dialog'),
//               subtitle: Text('Getx Dialog alert with getx'),
//               onTap: () {
//                 Get.defaultDialog(
//                   title: "Delete Chat",
//                   titlePadding: EdgeInsets.only(top: 20),
//                   contentPadding: EdgeInsets.all(20),
//                   middleText: "Are you sure you want to delete this chat?",
//                   confirm: TextButton(
//                       onPressed: () {
//                         // Navigator.pop(context);
//                         Get.back();
//                       },
//                       child: Text('Ok')),
//                   cancel: TextButton(onPressed: () {}, child: Text('Cancel')),
//                 );
//               },
//             ),
//           ),
//           Card(
//             child: ListTile(
//               title: Text('Getx Bottom Sheet'),
//               subtitle: Text('Getx Dialog alert with getx'),
//               onTap: () {
//                 Get.bottomSheet(
//                   Container(
//                     decoration: BoxDecoration(
//                       color: Colors.red,
//                       borderRadius: BorderRadius.circular(30),
//                     ),
//                     child: Column(
//                       children: [
//                         ListTile(
//                           title: Text('Light Mode'),
//                           onTap: () {
//                             Get.changeTheme(
//                               ThemeData.light(),
//                             );
//                           },
//                           leading: Icon(Icons.light_mode),
//                         ),
//                         ListTile(
//                           title: Text('Dark Mode'),
//                           onTap: () {
//                             Get.changeTheme(
//                               ThemeData.dark(),
//                             );
//                           },
//                           leading: Icon(Icons.dark_mode),
//                         )
//                       ],
//                     ),
//                   ),
//                 );
//               },
//             ),
//           ),
//         ],
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: () {
//           Get.snackbar(
//             'Hello',
//             'This is a snackbar',
//             backgroundColor: Colors.blue,
//             onTap: (snap) {
//               print(snap);
//             },
//             mainButton: TextButton(
//               onPressed: () {},
//               child: Text('Click Me'),
//             ),
//             icon: Icon(Icons.add),
//             margin: EdgeInsets.all(20),
//             snackPosition: SnackPosition.BOTTOM,
//           );
//         },
//       ),
//     );
//   }
// }

/*
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Screen'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Center(
            child: TextButton(
              onPressed: () {
                // Get.to(ScreenOne(name: 'Rajan',));
                Get.toNamed('/screenOne', arguments: ['Rajan', 'Sumit','3rd']);
                // Navigator.push(
                //   context,MaterialPageRoute(builder: (context) {
                //     return ScreenOne();
                //   },),
                // );
              },
              child: Text('Goto Next Screen'),
            ),
          ),
        ],
      ),
    );
  }
}
*/

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final CounterController controller = Get.put(CounterController());


  //state
  // @override
  // void initState() {
  //   // TODO: implement initState
  //   super.initState();
  //   Timer.periodic(Duration(milliseconds: 500), (timer) {
  //     x++;
  //     setState(() {});
  //   });
  // }

  // counter
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    print('Print');
    return Scaffold(
        appBar: AppBar(
          title: Text('Home Screen'),
        ),
        // region  -> get with and hight
        // body: Column(
        //   children: [
        //     Container(
        //       height: Get.height * .2,
        //       width: Get.width *.8,
        //       color: Colors.red,
        //       child: Center(
        //         child: Text('Home Screen'),
        //       ),
        //     ),
        //     Container(
        //       height: Get.height * .1,
        //       width: Get.width *.8,
        //       color: Colors.green,
        //       child: Center(
        //         child: Text('Home Screen'),
        //       ),
        //     ),
        //   ],
        // ),
        // endregion
        // region  -> get translations
        // body: Column(
        //     mainAxisAlignment: MainAxisAlignment.center,
        //     crossAxisAlignment: CrossAxisAlignment.center,
        //     children: [
        //       ListTile(
        //         title: Text('message'.tr),
        //         subtitle: Text('name'.tr),
        //       ),
        //       SizedBox(
        //         height: 50,
        //       ),
        //       Row(
        //         children: [
        //           OutlinedButton(
        //             onPressed: () {
        //               Get.updateLocale(Locale('en', 'US'));
        //             },
        //             child: Text('English'),
        //           ),
        //           SizedBox(
        //             width: 20,
        //           ),
        //           OutlinedButton(
        //             onPressed: () {
        //               // Get.updateLocale(Locale('ur', 'PK'));
        //               Get.updateLocale(Locale('hi', 'IN'));
        //             },
        //             child: Text('Hindi'),
        //           ),
        //         ],
        //       )
        //     ]),
        // endregion
        // region  -> state
        // body: Column(
        //   children: [
        //     Center(
        //       child: Text(
        //         x.toString(),
        //         style: TextStyle(fontSize: 60),
        //       ),
        //     ),
        //     Expanded(
        //       child: ListView.builder(
        //         itemCount: 10808,
        //         itemBuilder: (context, index) {
        //           return ListTile(
        //             title: Text(
        //               'Item $index',
        //             )
        //           );
        //         },
        //       ),
        //     ),
        //   ],
        // ),
        // floatingActionButton: FloatingActionButton(onPressed: () {
        //   x++;
        //   setState(() {});
        // })
        // endregion
      // region  -> getx counter
      body: Center(
        child: Obx(() => Text(
          controller.count.toString(),
          style: TextStyle(fontSize: 60),
        )),
      ),
      floatingActionButton: FloatingActionButton(onPressed: () {
        controller.incrementCounter();
      })
      // endregion
        );
  }
}
