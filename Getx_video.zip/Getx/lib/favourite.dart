import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getx/getx/favourite_controller.dart';

class Favourite extends StatefulWidget {
  const Favourite({super.key});

  @override
  State<Favourite> createState() => _FavouriteState();
}

class _FavouriteState extends State<Favourite> {
  FavouriteController favouriteController = Get.put(FavouriteController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Getx Tutorial"),
      ),
      body: ListView.builder(
        itemCount: favouriteController.fruitList.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              onTap: () {
                if (favouriteController.tempList.contains(
                    favouriteController.fruitList[index].toString())) {
                  favouriteController.removeFromFavourite(
                      favouriteController.fruitList[index].toString());
                } else {
                  favouriteController.addToFavourite(
                      favouriteController.fruitList[index].toString());
                }
              },
              title: Text(
                favouriteController.fruitList[index].toString(),
              ),
              trailing: Obx(
                () => Icon(
                  Icons.favorite,
                  color: favouriteController.tempList.contains(
                          favouriteController.fruitList[index].toString())
                      ? Colors.red
                      : Colors.white,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
