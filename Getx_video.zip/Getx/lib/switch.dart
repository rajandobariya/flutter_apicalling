import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getx/getx/example_swith.dart';

class SwitchExample extends StatefulWidget {
  const SwitchExample({super.key});

  @override
  State<SwitchExample> createState() => _SwitchExampleState();
}

class _SwitchExampleState extends State<SwitchExample> {
  ExampleController exampleController = Get.put(ExampleController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Switch Example'),
      ),
      body: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Notification"),
              Obx(
                () => Switch(
                  value: exampleController.notification.value,
                  onChanged: (value) {
                    exampleController.setNotification(value);
                  },
                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}
