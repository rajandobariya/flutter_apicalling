import 'package:get/get.dart';

class FavouriteController extends GetxController {
  RxList<String> fruitList = [
    "Apple",
    "Orange",
    "Grapes",
    "Banana",
  ].obs;
  RxList tempList = [].obs;

  addToFavourite(String fruit) {
    tempList.add(fruit);
  }

  removeFromFavourite(String fruit) {
    tempList.remove(fruit);
  }
}
