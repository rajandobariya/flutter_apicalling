import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getx/favourite.dart';
import 'package:getx/getx_example.dart';
import 'package:getx/home_screen.dart';
import 'package:getx/image_picker.dart';
import 'package:getx/langauage.dart';
import 'package:getx/login_page.dart';
import 'package:getx/screen_one.dart';
import 'package:getx/screen_two.dart';
import 'package:getx/switch.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      locale: Locale('en', 'US'),
      translations: Languages(),
      fallbackLocale: Locale('en', 'US'),
      theme: ThemeData(
        primarySwatch: Colors.blue
      ),
      home: Login(),
      getPages: [
        GetPage(name: '/', page: () => HomeScreen()),
        GetPage(name: '/screenOne', page: () => ScreenOne()),
        GetPage(name: '/screenTwo', page: () => ScreenTwo()),
      ],
    );
  }
}