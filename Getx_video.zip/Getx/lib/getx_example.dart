import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getx/getx/example_two.dart';

class Getx extends StatefulWidget {
  const Getx({super.key});

  @override
  State<Getx> createState() => _GetxState();
}

class _GetxState extends State<Getx> {


  ExampleTwoController exampleTwoController = Get.put(ExampleTwoController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Getx'),
      ),
      body: Column(
        children: [
          Obx(() => Container(
            height: 200,
            width: 200,
            color: Colors.red.withOpacity(exampleTwoController.opacity.value),
          ),),
          Obx(() =>Slider(
            value: exampleTwoController.opacity.value,
            onChanged: (value) {
              exampleTwoController.setOpacity(value);
            },
          ), ),


        ],
      ),
    );
  }
}
