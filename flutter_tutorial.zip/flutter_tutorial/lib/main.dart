import 'package:flutter/material.dart';
import 'package:flutter_tutorial/animated_page.dart';
import 'package:flutter_tutorial/bmi_page.dart';
import 'package:flutter_tutorial/login/home_page.dart';
import 'package:flutter_tutorial/login/login_page.dart';
import 'package:flutter_tutorial/login/splash_page.dart';
import 'package:flutter_tutorial/second.dart';
import 'package:flutter_tutorial/switch_page.dart';
import 'package:flutter_tutorial/third_page.dart';
import 'package:flutter_tutorial/ui/text_theme.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          primarySwatch: Colors.orange,
          useMaterial3: true,
          textTheme: TextTheme(
            headline1: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            subtitle1: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                fontStyle: FontStyle.italic),
          )),
      home: Splash(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  var date = '';
  final DateFormat _dateFormat = DateFormat('yyyy/MM/dd'); // Format for 'YYYYMMDD'

  var timeer = '';
  final DateFormat _timeFormat = DateFormat('hh:mm:ss a'); // Format for 'hh:mm:ss'


  var password = TextEditingController();
  var emailtext = TextEditingController();
  var time = DateTime.now();

  var name = [
    'Flutter',
    'Dart',
    'Android',
    'iOS',
    'Web',
    'Flutter',
    'Flutter',
    'Dart',
    'Android',
    'iOS',
    'Web',
    'Flutter',
    'Flutter',
    'Dart',
    'Android',
    'iOS',
    'Web',
    'Flutter',
    'Flutter',
    'Dart',
    'Android',
    'iOS',
    'Web',
    'Flutter'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: Text("Flutter Demo"),
      ),
      //region -> Container
      // body: Center(
      //   child: Container(
      //       width: 200,
      //       height: 100,
      //       color: Colors.blueGrey,
      //       child: Center(child: Text("This is Center of Container",style: TextStyle(fontSize: 16,color: Colors.white),))),
      // ),
      //endregion
      //region -> Text
      // body: Text("This is Text",style: TextStyle(
      //   fontSize: 24,
      //   color: Colors.lightBlue,
      //   fontWeight: FontWeight.bold,
      //   backgroundColor: Colors.deepOrangeAccent
      // ),),
      //endregion
      //region -> TextButton
      // body: TextButton(
      //   onPressed: () {
      //     print('Text Button Clicked');
      //   },
      //   child: Text("Click here!!"),
      // ),
      //endregion
      //region -> ElevatedButton
      // body: ElevatedButton(
      //   onPressed: () {
      //     print('Elevated Button Clicked');
      //   },
      //   child: Text("Click here!!"),
      // ),
      //endregion
      //region -> OutlinedButton
      // body: OutlinedButton(onPressed: (){
      //   print('Outlined Button Clicked');
      // }, child: Text("Click here!!")),
      //endregion
      //region -> Image
      // body: Center(child: Container(
      //     width: 100,
      //     height: 100,
      //     child: Image.asset('assets/image1.png',fit: BoxFit.cover,))),
      //endregion
      //region -> Row and Column
      // body: Container(
      //   height: 300,
      //   child: Column(
      //     mainAxisAlignment: MainAxisAlignment.start,
      //     crossAxisAlignment: CrossAxisAlignment.start,
      //     children: [
      //       Row(
      //         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      //         children: [
      //           Column(
      //             children: [
      //               ElevatedButton(onPressed: (){
      //
      //               }, child: Text("Button 1!!")),
      //               ElevatedButton(onPressed: (){
      //
      //               }, child: Text("Button 1!!"))
      //             ],
      //           ),
      //           Text('R1',style: TextStyle(fontSize: 24),),
      //           Text('R2',style: TextStyle(fontSize: 24),),
      //           Text('R3',style: TextStyle(fontSize: 24),),
      //           Text('R4',style: TextStyle(fontSize: 24),),
      //           Text('R5',style: TextStyle(fontSize: 24),),
      //         ],
      //       ),
      //       Text('A',style: TextStyle(fontSize: 24),),
      //       Text('B',style: TextStyle(fontSize: 24),),
      //       Text('C',style: TextStyle(fontSize: 24),),
      //       Text('D',style: TextStyle(fontSize: 24),),
      //       Text('E',style: TextStyle(fontSize: 24),),
      //
      //     ],
      //   ),
      // ),
      //endregion
      // region -> InkWell
      // body:Center(
      //   child: InkWell(
      //     onTap: (){
      //       print('InkWell Clicked');
      //     },
      //     child: Container(
      //       height: 300,
      //       width: 300,
      //       color: Colors.amber,
      //       child: Center(child: InkWell(
      //           onTap: (){
      //             print('InkWell Clicked');
      //           },
      //           child: Text('Click here!!',style: TextStyle(fontSize: 20,fontWeight: FontWeight.w700),))),
      //     ),
      //   ),
      // ) ,
      //endregion
      // region -> ScrollView vertical and horizontal
      // body: Padding(
      //   padding: const EdgeInsets.all(6.0),
      //   child: SingleChildScrollView(
      //     child: Column(
      //       children: [
      //         SingleChildScrollView(
      //           scrollDirection: Axis.horizontal,
      //           child: Row(
      //             children: [
      //               Container(
      //                 margin: EdgeInsets.all(6),
      //                 height: 200,
      //                 width: 200,
      //                 color: Colors.lightGreen,
      //               ),Container(
      //                 margin: EdgeInsets.all(6),
      //                 height: 200,
      //                 width: 200,
      //                 color: Colors.orange,
      //               ),Container(
      //                 margin: EdgeInsets.all(6),
      //                 height: 200,
      //                 width: 200,
      //                 color: Colors.blue,
      //               ),Container(
      //                 margin: EdgeInsets.all(6),
      //                 height: 200,
      //                 width: 200,
      //                 color: Colors.grey,
      //               )
      //             ],
      //           ),
      //         ),
      //         Container(
      //           height: 200,
      //           color: Colors.lightGreen,
      //           margin: EdgeInsets.all(6),
      //         ),
      //         Container(
      //           height: 200,
      //           color: Colors.orange,
      //           margin: EdgeInsets.all(6),
      //         ),
      //         Container(
      //           height: 200,
      //           color: Colors.blue,
      //           margin: EdgeInsets.all(6),
      //         ),
      //         Container(
      //           height: 200,
      //           color: Colors.grey,
      //           margin: EdgeInsets.all(6),
      //         ),
      //       ],
      //     ),
      //   ),
      // ),
      //endregion
      // region -> ListView
      // body: ListView(
      //   scrollDirection: Axis.vertical,
      //   reverse: true,
      //   children: [
      //     Padding(
      //       padding: const EdgeInsets.all(8.0),
      //       child: Text('One',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
      //     ),
      //     Padding(
      //       padding: const EdgeInsets.all(8.0),
      //       child: Text('Two',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
      //     ),
      //     Padding(
      //       padding: const EdgeInsets.all(8.0),
      //       child: Text('Three',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
      //     ),
      //     Padding(
      //       padding: const EdgeInsets.all(8.0),
      //       child: Text('Four',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
      //     ),
      //     Padding(
      //       padding: const EdgeInsets.all(8.0),
      //       child: Text('Five',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
      //     ),
      //   ]
      // )
      //endregion
      // region -> ListView.builder and ListView.separated
      // body: ListView.separated(
      //   separatorBuilder: (context, index) {
      //     return Divider(height: 100,thickness: 1,);
      //   },
      //   scrollDirection: Axis.vertical,
      //   itemCount: name.length,
      //   itemBuilder: (context, index) {
      //     return Row(
      //       children: [
      //         Padding(
      //           padding: const EdgeInsets.all(8.0),
      //           child: Column(
      //             children: [
      //               Text(name[index],style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),),
      //               Padding(
      //                 padding: const EdgeInsets.all(8.0),
      //                 child: Text(name[index],style: TextStyle(fontSize: 11,fontWeight: FontWeight.w500),),
      //               ),
      //             ],
      //           ),
      //         ),
      //
      //         Padding(
      //           padding: const EdgeInsets.all(8.0),
      //           child: Text(name[index],style: TextStyle(fontSize: 21,fontWeight: FontWeight.w500),),
      //         ),
      //       ],
      //     );
      //   },
      // ),
      //endregion
      // region -> Container design and decoration
      // body: Container(
      //   width: double.infinity,
      //   height: double.infinity,
      //   child: Center(
      //     child: Container(
      //       width: 100,
      //       height: 100,
      //       decoration: BoxDecoration(
      //         border: Border.all(width: 2, color: Colors.black),
      //         // borderRadius: BorderRadius.all(Radius.circular(10)),
      //         color: Colors.blueGrey,
      //         boxShadow: [
      //           BoxShadow(spreadRadius: 21, blurRadius: 51, color: Colors.grey)
      //         ],
      //         shape: BoxShape.circle,
      //       ),
      //     ),
      //   ),
      // ),
      //endregion
      // region -> Expanded & Flexible
      // body: Row(
      //   children: [
      //     Expanded(
      //       flex: 2,
      //       child: Container(
      //         height: 100,
      //         color: Colors.blue,
      //       ),
      //     ),
      //     Expanded(
      //       flex: 1,
      //       child: Container(
      //         height: 100,
      //         color: Colors.orange,
      //       ),
      //     ),
      //     Expanded(
      //       flex: 2,
      //       child: Container(
      //         height: 100,
      //         color: Colors.deepPurple,
      //       ),
      //     ),
      //     Expanded(
      //       flex: 4,
      //       child: Container(
      //         height: 100,
      //         color: Colors.green,
      //       ),
      //     ),
      //   ],
      // ),
      //endregion
      // region -> margin and padding
      // body: Container(
      //     color: Colors.blue,
      //     padding: EdgeInsets.all(10),
      //     margin: EdgeInsets.all(10),
      //     child: Text('Hello',style: TextStyle(fontSize: 20),)),
      //endregion
      // region -> ListTile
      // body: ListView.separated(
      //     itemBuilder: (context, index) {
      //       return ListTile(
      //         leading: Text('${index + 1}'),
      //         title:Text(name[index]),
      //         subtitle: Text('number'),
      //         trailing: Icon(Icons.add),
      //
      //       );
      //     },
      //     separatorBuilder: (context, index) {
      //       return Divider(height: 28,thickness: 1,);
      //     },
      //     itemCount: name.length),
      //endregion
      // region -> CircleAvatar
      // body: Center(
      //   child: CircleAvatar(
      //     child: Text('A',style: TextStyle(color: Colors.white,fontSize: 20),),
      //     minRadius: 100,
      //     maxRadius: 110,
      //     backgroundImage: NetworkImage('https://cdn-icons-png.flaticon.com/512/12662/12662538.png'),
      //     backgroundColor: Colors.orange,
      //   ),
      // ),
      //endregion
      // region -> FontFamily
      // body: Center(child: Text('Hello',style: TextStyle(fontFamily: 'Roboto'),)),
      //endregion
      // region -> Style and Theme
      // body: Column(
      //   children: [
      //     Text('Hello', style: Theme.of(context).textTheme.headline1!.copyWith(fontStyle: FontStyle.italic)),
      //     Text('Hello', style: Theme.of(context).textTheme.subtitle1),
      //     Text('Hello', style: Theme.of(context).textTheme.headline1),
      //     Text('Hello', style: style11(color: Colors.red)),
      //
      //   ],
      // ),
      //endregion
      // region -> Card
      // body: Center(
      //   child: Card(
      //     shadowColor: Colors.green,
      //     elevation: 12,
      //     child: Padding(
      //       padding: const EdgeInsets.all(8.0),
      //       child: Text('Hello',style: TextStyle(fontSize: 20),),
      //     ),
      //   ),
      // ),
      // endregion
      // region -> TextInput =  Textfield
      // body: Center(
      //   child: Padding(
      //     padding: const EdgeInsets.all(6),
      //     child: Column(
      //       mainAxisAlignment: MainAxisAlignment.center,
      //       // crossAxisAlignment: CrossAxisAlignment.center,
      //       children: [
      //         Container(
      //           margin: EdgeInsets.all(6),
      //           child: Text(
      //             "Login Page",
      //             style: TextStyle(
      //                 color: Colors.red, fontSize: 20, fontFamily: 'Poppins'),
      //           ),
      //         ),
      //         Container(
      //           height: 55,
      //           margin: EdgeInsets.all(6),
      //           child: TextField(
      //             decoration: InputDecoration(
      //               focusedBorder: OutlineInputBorder(
      //                 borderRadius: BorderRadius.circular(12),
      //                 borderSide: BorderSide(
      //                   color: Colors.deepPurple,
      //                   width: 1,
      //                 ),
      //               ),
      //               enabledBorder: OutlineInputBorder(
      //                 borderRadius: BorderRadius.circular(12),
      //                 borderSide: BorderSide(color: Colors.red, width: 1),
      //               ),
      //               disabledBorder: OutlineInputBorder(
      //                 borderRadius: BorderRadius.circular(12),
      //                 borderSide: BorderSide(color: Colors.brown, width: 1),
      //               ),
      //               suffixIcon: Icon(Icons.email),
      //             ),
      //             controller: emailtext,
      //           ),
      //         ),
      //         Container(
      //           height: 55,
      //           margin: EdgeInsets.all(6),
      //           child: TextField(
      //             decoration: InputDecoration(
      //               focusedBorder: OutlineInputBorder(
      //                 borderRadius: BorderRadius.circular(12),
      //                 borderSide: BorderSide(
      //                   color: Colors.deepPurple,
      //                   width: 1,
      //                 ),
      //               ),
      //               enabledBorder: OutlineInputBorder(
      //                 borderRadius: BorderRadius.circular(12),
      //                 borderSide: BorderSide(color: Colors.red, width: 1),
      //               ),
      //               disabledBorder: OutlineInputBorder(
      //                 borderRadius: BorderRadius.circular(12),
      //                 borderSide: BorderSide(color: Colors.brown, width: 1),
      //               ),
      //               suffixIcon: Icon(Icons.remove_red_eye),
      //               // prefixIcon: IconButton(
      //               //   icon: Icon(Icons.remove_red_eye),
      //               //   onPressed: () {},
      //               // ),
      //             ),
      //             controller: password,
      //             obscureText: true,
      //           ),
      //         ),
      //         Container(
      //           margin: EdgeInsets.all(6),
      //           height: 50,
      //           width: 150,
      //           decoration: BoxDecoration(
      //               color: Colors.red, borderRadius: BorderRadius.circular(12)),
      //           child: Center(
      //             child: InkWell(
      //               onTap: () {
      //                 String email = emailtext.text.toString();
      //                 String pass = password.text.toString();
      //
      //                 if (email.isEmpty) {
      //                   print("Please Enter Email");
      //                   return;
      //                 } else if (pass.isEmpty) {
      //                   print("Please Enter Password");
      //                   return;
      //                 }
      //                 message(email);
      //                 message(pass);
      //               },
      //               child: Text("Login",
      //                   style: TextStyle(
      //                       color: Colors.white,
      //                       fontFamily: 'Poppins',
      //                       fontSize: 20)),
      //             ),
      //           ),
      //         )
      //       ],
      //     ),
      //   ),
      // ),
      // endregion
      // region -> Current Date & Time
      // body: Center(
      //   child: Container(
      //     margin: EdgeInsets.all(6),
      //     width: 200,
      //     height: 200,
      //     child: Column(
      //       mainAxisAlignment: MainAxisAlignment.center,
      //       children: [
      //         Text(
      //           'Current time : ${time.hour}:${time.minute}:${time.second}',
      //           style: TextStyle(fontSize: 18),
      //         ),
      //         ElevatedButton(
      //           onPressed: () {
      //             setState(() {
      //               time = DateTime.now();
      //             });
      //           },
      //           child: Text('Current Time'),
      //         ),
      //       ],
      //     ),
      //   ),
      // ),
      // endregion
      // region -> Format Date
      // body: Center(
      //   child: Container(
      //     margin: EdgeInsets.all(6),
      //     width: 200,
      //     height: 200,
      //     child: Column(
      //       mainAxisAlignment: MainAxisAlignment.center,
      //       children: [
      //         Text(
      //           'Current time : ${DateFormat('MMMM').format(time)}',
      //           style: TextStyle(fontSize: 18),
      //         ),
      //         ElevatedButton(
      //           onPressed: () {
      //             setState(() {
      //               time = DateTime.now();
      //             });
      //           },
      //           child: Text('Current Time'),
      //         ),
      //       ],
      //     ),
      //   ),
      // ),
      // endregion
      // region -> Format Datepicker & Timepicker
      // body: Column(
      //   children: [
      //     Text(
      //       date.isEmpty ? 'Select date' : 'Selected date: ${date}',
      //       style: TextStyle(fontSize: 18),
      //     ),
      //     ElevatedButton(
      //       onPressed: () async {
      //         DateTime? pickedDate = await showDatePicker(
      //           context: context,
      //           initialDate: DateTime.now(),
      //           firstDate: DateTime(2000),
      //           lastDate: DateTime(2101),
      //         );
      //         if (pickedDate != null) {
      //           setState(() {
      //             date = _dateFormat.format(pickedDate);
      //           });
      //         }
      //       },
      //       child: Text('Show Date Picker'),
      //     ),
      //
      //     Text(
      //       timeer.isEmpty ? 'Select time' : 'Selected time: ${timeer}',
      //       style: TextStyle(fontSize: 18),
      //     ),
      //     ElevatedButton(
      //       onPressed: () async {
      //         TimeOfDay? pickedTime = await showTimePicker(
      //           context: context,
      //           initialTime: TimeOfDay.now(),
      //           initialEntryMode: TimePickerEntryMode.input,
      //         );
      //         if (pickedTime != null) {
      //           setState(() {
      //             timeer = _timeFormat.format(
      //               DateTime(2023, 1, 1, pickedTime.hour, pickedTime.minute),
      //             );
      //           });
      //         }
      //       },
      //       child: Text('Select Time'),
      //     ),
      //
      //   ],
      // ),
      // endregion  &


    );
  }
}

void message(String msg) {
  print(msg);
}
