import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_tutorial/ui/hero_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Animated extends StatefulWidget {
  const Animated({super.key});

  @override
  State<Animated> createState() => _AnimatedState();
}

class _AnimatedState extends State<Animated>
    with SingleTickerProviderStateMixin {
  var _width = 200.0;
  var _height = 100.0;

  bool flag = true;
  Decoration myDecoration = BoxDecoration(
      borderRadius: BorderRadius.circular(10), color: Colors.blue);

  var myOpacity = 1.0;
  bool isvisible = true;

  bool isFirst = true;

  var arrIndex = [
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20
  ];
  var wtController = TextEditingController();
  var ftController = TextEditingController();
  var inController = TextEditingController();

  // var result = "No Value";

  // @override
  // void initState() {
  //   // TODO: implement initState
  //   super.initState();
  //   // Timer(Duration(seconds: 4), () {
  //   //   reload();
  //   // });
  // }

  void reload() {
    setState(() {
      if (isFirst) {
        isFirst = false;
      } else {
        isFirst = true;
      }
    });
  }

  var arrData = [
    {'name': 'Raman', 'mobno': '9826567890', 'unread': '2'},
    {'name': 'Rahul', 'mobno': '96545656565', 'unread': '1'},
    {'name': 'Rajeev', 'mobno': '97656565656', 'unread': '5'},
    {'name': 'Raj', 'mobno': '92356565656', 'unread': '3'},
    {'name': 'Raman', 'mobno': '9826567890', 'unread': '2'},
    {'name': 'Rahul', 'mobno': '96545656565', 'unread': '1'},
    {'name': 'Rajeev', 'mobno': '97656565656', 'unread': '5'},
    {'name': 'Raj', 'mobno': '92356565656', 'unread': '3'},
    {'name': 'Raman', 'mobno': '9826567890', 'unread': '2'},
    {'name': 'Rahul', 'mobno': '96545656565', 'unread': '1'},
    {'name': 'Rajeev', 'mobno': '97656565656', 'unread': '5'},
    {'name': 'Raj', 'mobno': '92356565656', 'unread': '3'},
    {'name': 'Raman', 'mobno': '9826567890', 'unread': '2'},
    {'name': 'Rahul', 'mobno': '96545656565', 'unread': '1'},
    {'name': 'Rajeev', 'mobno': '97656565656', 'unread': '5'},
    {'name': 'Raj', 'mobno': '92356565656', 'unread': '3'}
  ];

  /* late Animation animation;
  late AnimationController animationController;
  late Animation coloranimation;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    animationController = AnimationController(
      vsync: this,
      duration: Duration(seconds: 4),
    );
    animation = Tween(begin: 0.0, end: 200.0).animate(animationController);
    coloranimation = ColorTween(begin: Colors.blue, end: Colors.orange).animate(animationController);
    animationController.addListener(() {
      setState(() {});
    });
    animationController.forward();
  }*/
  /*var listradius = [150.0, 200.0, 250.0, 300.0, 350.0];
  late AnimationController _controller;
  late Animation _animation;

  @override
  void initState() {
    // TODO: implement initState
    _controller =
        AnimationController(vsync: this, duration: Duration(seconds: 4),lowerBound: 0.5);
    // _animation = Tween(begin: 0.0, end: 1.0).animate(_controller);

    _controller.addListener(() {
      setState(() {});
    });
    _controller.forward();
  }*/
  var nameController = TextEditingController();
  static const String KAYNAME = 'name';
  var nameValue = "No Value";

  @override
  void initState() {
    super.initState();
    getValue();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: Text("Flutter Demo"),
      ),
      // region -> animated
      // body: Center(
      //   child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      //     AnimatedContainer(
      //       duration: Duration(seconds: 2),
      //       width: _width,
      //       height: _height,
      //       curve: Curves.slowMiddle,
      //       decoration: myDecoration,
      //     ),
      //     ElevatedButton(
      //       onPressed: () {
      //
      //         setState(() {
      //           if(flag){
      //             _width =100;
      //             _height = 200;
      //             myDecoration = BoxDecoration(
      //               color: Colors.orange,
      //               borderRadius: BorderRadius.circular(30),
      //             );
      //             flag = false;
      //           }else{
      //             _width =200;
      //             _height = 100;
      //             myDecoration = BoxDecoration(
      //               color: Colors.blue,
      //               borderRadius: BorderRadius.circular(10),
      //             );
      //             flag = true;
      //           }
      //         });
      //       },
      //       child: Text("Animate"),
      //     )
      //   ]),
      // ),
      // endregion
      // region -> animated opacity
      // body: Column(
      //   children: [
      //     AnimatedOpacity(
      //         opacity: myOpacity,
      //         curve: Curves.slowMiddle,
      //         duration: Duration(seconds: 1),
      //         child: Container(
      //           width: 200,
      //           height: 100,
      //           color: Colors.blue,
      //         )),
      //     ElevatedButton(
      //       onPressed: () {
      //         setState(() {
      //           if (isvisible) {
      //             myOpacity = 0.0;
      //             isvisible = false;
      //           }else{
      //             myOpacity = 1.0;
      //             isvisible = true;
      //           }
      //         });
      //       },
      //       child: Text("Close"),
      //     )
      //   ],
      // ),
      // endregion
      // region -> CrossFade
      // body: Center(
      //   child: Column(
      //     mainAxisAlignment: MainAxisAlignment.center,
      //     children: [
      //       AnimatedCrossFade(
      //         firstChild: Container(
      //           width: 200,
      //           height: 200,
      //           color: Colors.grey,
      //         ),
      //         sizeCurve: Curves.fastOutSlowIn,
      //         firstCurve: Curves.easeInOut,
      //         secondCurve: Curves.bounceInOut,
      //         duration: Duration(seconds: 4),
      //         crossFadeState: isFirst
      //             ? CrossFadeState.showFirst
      //             : CrossFadeState.showSecond,
      //         secondChild: Image.asset("assets/image1.png",
      //             width: 100, height: 100, fit: BoxFit.cover),
      //       ),
      //       ElevatedButton(
      //           onPressed: () {
      //             reload();
      //           },
      //           child: Text("Show")),
      //     ],
      //   ),
      // ),
      // endregion
      // region -> Hero Animation
      // body: Container(
      //   child: Center(
      //     child: InkWell(
      //       onTap: () {
      //         Navigator.push(context, MaterialPageRoute(builder: (context) {
      //           return DetailPage();
      //         }));
      //       },
      //       child: Hero(
      //         tag: "hero",
      //         child: Image.asset(
      //           "assets/image1.png",
      //         ),
      //       ),
      //     ),
      //   ),
      // ),
      // endregion
      // region -> List Wheel Scroll
      // body: ListWheelScrollView(
      //   itemExtent: 200,
      //   children: arrIndex
      //       .map((e) => Container(
      //             child: Center(
      //               child: Text(
      //                 'Item $e',
      //                 style: TextStyle(color: Colors.white),
      //               ),
      //             ),
      //             decoration: BoxDecoration(
      //               color: Colors.blue,
      //               borderRadius: BorderRadius.circular(10),
      //             ),
      //             width: MediaQuery.of(context).size.width,
      //           ))
      //       .toList(),
      // ),
      // endregion
      // region -> ClipRRect
      // body: Center(
      //   child: ClipRRect(
      //     borderRadius: BorderRadius.circular(40),
      //     child: Image.asset(
      //       "assets/image1.png",
      //     )
      //   )
      // ),
      // endregion
      // region ->LinearGradient color
      // body: Container(
      //   decoration: BoxDecoration(
      //       gradient: LinearGradient(
      //     colors: [Color(0xFFFFECD2), Color(0xFFFCB69F)],
      //     begin: FractionalOffset(1.0, 0.0),
      //     end: FractionalOffset(0.0, 1.0),
      //     stops: [0.0, 1.0],
      //   )),
      //   child: Center(
      //     child: Container(
      //       width: 300,
      //       child: Column(
      //         mainAxisAlignment: MainAxisAlignment.center,
      //         children: [
      //           Text(
      //             'BMI',
      //             style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
      //           ),
      //           SizedBox(
      //             height: 20,
      //           ),
      //           TextField(
      //             controller: wtController,
      //             decoration: InputDecoration(
      //               hintText: 'Enter Your Weight(in Kg)',
      //               prefixIcon: Icon(Icons.line_weight),
      //             ),
      //             keyboardType: TextInputType.number,
      //           ),
      //           SizedBox(
      //             height: 10,
      //           ),
      //           TextField(
      //             controller: ftController,
      //             decoration: InputDecoration(
      //               hintText: 'Enter Your Height(in Feet)',
      //               prefixIcon: Icon(Icons.height),
      //             ),
      //             keyboardType: TextInputType.number,
      //           ),
      //           SizedBox(
      //             height: 10,
      //           ),
      //           TextField(
      //             controller: inController,
      //             decoration: InputDecoration(
      //               hintText: 'Enter Your Height(in Inch)',
      //               prefixIcon: Icon(Icons.height),
      //             ),
      //             keyboardType: TextInputType.number,
      //           ),
      //           SizedBox(
      //             height: 20,
      //           ),
      //           ElevatedButton(
      //             onPressed: () {
      //               var wt = wtController.text.toString();
      //               var ft = ftController.text.toString();
      //               var inch = inController.text.toString();
      //               if (wt != "" && ft != "" && inch != "") {
      //                 var iwt = int.parse(wt);
      //                 var ift = int.parse(ft);
      //                 var iinch = int.parse(inch);
      //
      //                 var tInch = (ift * 12) + iinch;
      //                 var tCm = tInch * 2.54;
      //                 var tM = tCm / 100;
      //                 var bmi = iwt / (tM * tM);
      //
      //                 var msg = "";
      //                 if (bmi > 25) {
      //                   msg = "You are OverWeight";
      //                 } else if (bmi < 18) {
      //                   msg = "You are UnderWeight";
      //                 } else {
      //                   msg = "You are Healthy";
      //                 }
      //                 setState(() {
      //                   result =
      //                       "$msg \n Your BMI is ${bmi.toStringAsFixed(2)}";
      //                 });
      //               } else {
      //                 setState(() {
      //                   result = "Please Fill all the required blanks!!";
      //                 });
      //               }
      //             },
      //             child: Text('Calculate'),
      //           ),
      //           SizedBox(
      //             height: 20,
      //           ),
      //           Text(
      //             result,
      //             style: TextStyle(fontSize: 20),
      //           ),
      //         ],
      //       ),
      //     ),
      //   ),
      // ),
      // endregion
      // region ->  Radial Gradient
      // body: Container(
      //   decoration: BoxDecoration(
      //       gradient: RadialGradient(
      //         colors: [Color(0xFFFFECD2), Color(0xFFFCB69F)],
      //         center: Alignment.center,
      //         stops: [0.0, 1.0],
      //       )),
      //   child: Center(
      //     child: Container(
      //       width: 300,
      //       child: Column(
      //         mainAxisAlignment: MainAxisAlignment.center,
      //         children: [
      //           Text(
      //             'BMI',
      //             style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
      //           ),
      //           SizedBox(
      //             height: 20,
      //           ),
      //           TextField(
      //             controller: wtController,
      //             decoration: InputDecoration(
      //               hintText: 'Enter Your Weight(in Kg)',
      //               prefixIcon: Icon(Icons.line_weight),
      //             ),
      //             keyboardType: TextInputType.number,
      //           ),
      //           SizedBox(
      //             height: 10,
      //           ),
      //           TextField(
      //             controller: ftController,
      //             decoration: InputDecoration(
      //               hintText: 'Enter Your Height(in Feet)',
      //               prefixIcon: Icon(Icons.height),
      //             ),
      //             keyboardType: TextInputType.number,
      //           ),
      //           SizedBox(
      //             height: 10,
      //           ),
      //           TextField(
      //             controller: inController,
      //             decoration: InputDecoration(
      //               hintText: 'Enter Your Height(in Inch)',
      //               prefixIcon: Icon(Icons.height),
      //             ),
      //             keyboardType: TextInputType.number,
      //           ),
      //           SizedBox(
      //             height: 20,
      //           ),
      //           ElevatedButton(
      //             onPressed: () {
      //               var wt = wtController.text.toString();
      //               var ft = ftController.text.toString();
      //               var inch = inController.text.toString();
      //               if (wt != "" && ft != "" && inch != "") {
      //                 var iwt = int.parse(wt);
      //                 var ift = int.parse(ft);
      //                 var iinch = int.parse(inch);
      //
      //                 var tInch = (ift * 12) + iinch;
      //                 var tCm = tInch * 2.54;
      //                 var tM = tCm / 100;
      //                 var bmi = iwt / (tM * tM);
      //
      //                 var msg = "";
      //                 if (bmi > 25) {
      //                   msg = "You are OverWeight";
      //                 } else if (bmi < 18) {
      //                   msg = "You are UnderWeight";
      //                 } else {
      //                   msg = "You are Healthy";
      //                 }
      //                 setState(() {
      //                   result =
      //                   "$msg \n Your BMI is ${bmi.toStringAsFixed(2)}";
      //                 });
      //               } else {
      //                 setState(() {
      //                   result = "Please Fill all the required blanks!!";
      //                 });
      //               }
      //             },
      //             child: Text('Calculate'),
      //           ),
      //           SizedBox(
      //             height: 20,
      //           ),
      //           Text(
      //             result,
      //             style: TextStyle(fontSize: 20),
      //           ),
      //         ],
      //       ),
      //     ),
      //   ),
      // ),
      // endregion
      // region ->  Mapping
      // body: Container(
      //   child: ListView(
      //     children: arrData
      //         .map(
      //           (e) => ListTile(
      //             leading: Icon(Icons.account_circle),
      //             title: Text(e['name'].toString()),
      //             subtitle: Text(e['mobno'].toString()),
      //             trailing: CircleAvatar(
      //                 radius: 12,
      //                 backgroundColor: Colors.green,
      //                 child: Text(e['unread'].toString())),
      //
      //           ),
      //         )
      //         .toList(),
      //   ),
      // ),
      // endregion
      // region ->  Tween Animation
      // body: Center(
      //   child: Container(
      //     width: animation.value,
      //     height: animation.value,
      //     color: coloranimation.value,
      //   ),
      // ),
      // endregion
      // region -> Ripple
      // body: Center(
      //   child: Stack(
      //     alignment: Alignment.center ,
      //     children: [
      //       buidMyContainer(listradius[0]),
      //       buidMyContainer(listradius[1]),
      //       buidMyContainer(listradius[2]),
      //       buidMyContainer(listradius[3]),
      //       buidMyContainer(listradius[4]),
      //       Icon(Icons.add_call, color: Colors.white,size: 34,)
      //     ]
      //   ),
      // ),
      // endregion
      // region -> Share Preferences
      body: Center(
        child: Container(
          child: SizedBox(
            width: 200,
            child:
                Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              TextField(
                  controller: nameController,
                  decoration: InputDecoration(
                    label: Text("Name"),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  )),
              SizedBox(
                height: 10,
              ),
              ElevatedButton(
                onPressed: () async {
                  var name = nameController.text.toString();
                  var prefs = await SharedPreferences.getInstance();
                  prefs.setString(KAYNAME, name);
                  setState(() {
                    nameValue = name;
                  });
                },
                child: Text("Save"),
              ),
              SizedBox(
                height: 10,
              ),
              Text(nameValue),
            ]),
          ),
        ),
      ),
      // endregion
    );
  }

  void getValue() async {
    var prefs = await SharedPreferences.getInstance();
    var getName = prefs.get(KAYNAME);
    nameValue = getName != null ? getName.toString() : "No Value Saved";
    setState(() {

    });
  }
// Widget buidMyContainer(e){
//   return  Container(
//     width: e * _controller.value,
//     height: e * _controller.value,
//     decoration: BoxDecoration(
//       shape: BoxShape.circle,
//       color: Colors.blue.withOpacity(1.0 - _controller.value),
//     ),
//   );
// }
}
