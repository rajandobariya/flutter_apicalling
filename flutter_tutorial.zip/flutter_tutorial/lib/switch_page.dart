import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_tutorial/third_page.dart';

class SwitchPage extends StatefulWidget {
  const SwitchPage({super.key});

  @override
  State<SwitchPage> createState() => _SwitchPageState();
}

class _SwitchPageState extends State<SwitchPage> {
  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds: 5), () {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
        return ThirdPage();
      }));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   backgroundColor: Colors.orange,
      //   title: Text("Flutter Demo"),
      // ),
      // region -> Switching
      // body: Center(
      //   child: Column(
      //     mainAxisAlignment: MainAxisAlignment.center,
      //     children: [
      //       Text('Welcome',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
      //       SizedBox(height: 11,),
      //       ElevatedButton(onPressed: (){
      //         Navigator.push(context, MaterialPageRoute(builder: (context) {
      //           return ThirdPage();
      //         }));
      //       }, child: Text("Next")),
      //     ],
      //   ),
      // )
      //endregion
      // region -> Splash Screen
      body: Container(
        color: Colors.blue,
        child: Center(
          child: Text('Splash Screen',
              style: TextStyle(color: Colors.white, fontSize: 20)),
        ),
      ),
      //endregion
    );
  }
}
