import 'package:flutter/material.dart';
import 'package:flutter_tutorial/main.dart';

class ThirdPage extends StatefulWidget {
  const ThirdPage({super.key});

  @override
  State<ThirdPage> createState() => _MyHomePage();
}

class _ThirdPageState extends State<ThirdPage> {
  int counter = 0;

  void increment() {
    setState(() {
      counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: Text('Third Page'),
      ),
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text('You have pushed the button this many times:'),
          Text(
            '$counter',
            style: Theme.of(context).textTheme.headline4,
          )
        ]),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: increment,
        tooltip: 'Increment',
        child: Icon(Icons.add),
      ),
    );
  }
}

class _MyHomePage extends State<ThirdPage> {
  var no1Controller = TextEditingController();
  var no2Controller = TextEditingController();

  var result = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: Text('Third Page'),
      ),
      // region -> Update Calculator
      // body: Container(
      //   color: Colors.blue,
      //   child: Center(
      //     child: Padding(
      //       padding: const EdgeInsets.all(8.0),
      //       child: Column(
      //         mainAxisAlignment: MainAxisAlignment.center,
      //         children: [
      //           TextField(
      //             keyboardType: TextInputType.number,
      //             controller: no1Controller,
      //           ),
      //           TextField(
      //             keyboardType: TextInputType.number,
      //             controller: no2Controller,
      //           ),
      //           Padding(
      //             padding: const EdgeInsets.all(8.0),
      //             child: Row(
      //               mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      //               children: [
      //                 ElevatedButton(
      //                     onPressed: () {
      //                       var num1 =
      //                           int.parse(no1Controller.text.toString());
      //                       var num2 =
      //                           int.parse(no2Controller.text.toString());
      //                       var sum = num1 + num2;
      //                       result = "The sum of $num1 and $num2 is $sum";
      //                       setState(() {});
      //                     },
      //                     child: Text('Add')),
      //                 ElevatedButton(
      //                     onPressed: () {
      //                       var num1 =
      //                           int.parse(no1Controller.text.toString());
      //                       var num2 =
      //                           int.parse(no2Controller.text.toString());
      //                       var sub = num1 - num2;
      //                       result = "The sub of $num1 and $num2 is $sub";
      //                       setState(() {});
      //                     },
      //                     child: Text('Sub')),
      //                 ElevatedButton(onPressed: () {
      //                   var num1 =
      //                       int.parse(no1Controller.text.toString());
      //                   var num2 =
      //                       int.parse(no2Controller.text.toString());
      //                   var mul = num1 * num2;
      //                   result = "The mul of $num1 and $num2 is $mul";
      //                   setState(() {});
      //                 }, child: Text('Mult')),
      //                 ElevatedButton(onPressed: () {
      //                   var num1 =
      //                       int.parse(no1Controller.text.toString());
      //                   var num2 =
      //                       int.parse(no2Controller.text.toString());
      //                   var div = num1 / num2;
      //                   result = "The div of $num1 and $num2 is ${div.toStringAsFixed(2)}";
      //                   setState(() {});
      //                 }, child: Text('Div')),
      //               ],
      //             ),
      //           ),
      //           Padding(
      //               padding: EdgeInsets.all(21),
      //               child: Text(
      //                 result.isEmpty ? "Result" : result,
      //                 style: TextStyle(fontSize: 25, color: Colors.white),
      //               )),
      //         ],
      //       ),
      //     ),
      //   ),
      // )
      // endregion
      // region -> ConstraintBox
      // body: ConstrainedBox(
      //     constraints: BoxConstraints(maxWidth: 200,maxHeight: 100),
      //     child: Text(
      //       "Hello WordHello WordHello WordHello WordHello WordHello WordHello WordHello WordHello WordHello WordHello WordHello WordHello WordHello WordHello WordHello WordHello WordHello WordHello Word",
      //       style: TextStyle(fontSize: 20,overflow: TextOverflow.fade),
      //     )),
      // endregion
      // region -> Switch Page
      // body: Text(
      //   'Welcome',
      //   style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
      // ),
      // endregion
    );
  }
}
