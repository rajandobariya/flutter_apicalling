import 'package:flutter/material.dart';
import 'package:flutter_tutorial/login/login_page.dart';
import 'package:flutter_tutorial/login/splash_page.dart';
import 'package:shared_preferences/shared_preferences.dart';
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Center(
          child: Text(
            'Home',
            style: TextStyle(color: Colors.white),
          ),
        ),
      ),
      body: Container(
        color: Colors.blue.shade100,
        child: Center(
          child: Column(
            children: [
              Icon(
                Icons.home,
                color: Colors.white,
              ),
              SizedBox(height: 11,),
              ElevatedButton(
                  onPressed: () async {
                    var sharepre = await SharedPreferences.getInstance();
                    sharepre.setBool(SplashState.KEYLOGIN, false);
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                      return LoginPage();
                    }));
                  },
                  child: Text("Log Out"))
            ],
          ),
        ),
      ),
    );
  }
}
