import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_tutorial/login/home_page.dart';
import 'package:flutter_tutorial/login/login_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Splash extends StatefulWidget {
  const Splash({super.key});

  @override
  State<Splash> createState() => SplashState();
}

class SplashState extends State<Splash> {
  static const String KEYLOGIN = 'Login';

  @override
  void initState() {
    super.initState();
    whereTogo();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
    color: Colors.blue,
    child: Center(
      child: Icon(
        Icons.account_circle,
        color: Colors.white,
        size: 100,
      ),
    ),
      ),
    );
  }

  void whereTogo() async {
    var sharedPreferences = await SharedPreferences.getInstance();
    var islogin = sharedPreferences.getBool(KEYLOGIN);
    Timer(Duration(seconds: 5), () {
      if (islogin != null && islogin) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) {
            return HomePage();
          }),
        );
      } else {
        Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (context) {
          return LoginPage();
        }));
      }
    });
  }
}
