import 'package:flutter/material.dart';
import 'package:flutter_tutorial/login/home_page.dart';
import 'package:flutter_tutorial/login/splash_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  var uNameController = TextEditingController();
  var passController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          title: Center(child: Text("Loggin")),
        ),
        body: Center(
            child:
                Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Padding(padding: EdgeInsets.all(21),child: Icon(Icons.account_circle,size: 100,color: Colors.blue,)),
          TextField(
              controller: uNameController,
              decoration: InputDecoration(
                  label: Text("Email"),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ))),
          SizedBox(
            height: 10,
          ),
          TextField(
              controller: passController,
              decoration: InputDecoration(
                  label: Text("Password"),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ))),
          ElevatedButton(
              onPressed: () async {
                var sharepre = await SharedPreferences.getInstance();
                sharepre.setBool(SplashState.KEYLOGIN, true);

                Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                  return HomePage();
                }));
              },
              child: Text("Login"))
        ])));
  }
}
