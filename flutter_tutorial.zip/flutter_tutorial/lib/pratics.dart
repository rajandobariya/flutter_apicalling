import 'dart:io';

void main() {
  print('Welcome to Flutter');

  // stdout.write('Enter your name: ');
  // var name = stdin.readLineSync();
  // print('Hello $name');

  Human();
  int a;
  a = 5;
  // print(a);
  BigInt b;
  b = BigInt.parse("65656565656565855454949944988498555");
  // print(b);
  a = 7;
  // print(a);

  // double or num
  num persentage = 99.65;
  bool isTrue = false;
  isTrue = true;

  String name1 = "Flutter";
  name1 = "Dart";

  String name2 = "Flutter";
  var subject = "English";
  subject = "xxss";

  // var or dynamic
  var section;
  section = "A";
  section = 5;
  int x = 55552;

  var mc = myClass();
  // mc.printName(name2);
  // mc.printName(x.toString());
  // print(mc.Add(6,1));
  // print(mc.Add(12,12));

  var myList = [10, 20, 30, 40];
  myList.add(50);
  var name = [];
  name.add("Flutter");
  name.add("Flutter");
  name.add("Flutter");
  name.add("Flutter");
  // name.addAll(myList);
  // name.insert(2, 100);
  // name.insertAll(3, myList);
  // name[0] = "Dart";

  // myList.replaceRange(0, 4,[1,2,3,4]);

  // myList.removeAt(2);
  // myList.removeLast();
  // myList.removeRange(0, 2);



  print("${myList.length}");
  print("${myList.reversed}");
  print('${myList.first}');
  print('${myList.last}');
  print('${myList.isEmpty}');
  print('${myList.isNotEmpty}');
  print('${myList.elementAt(1)}');


}

class Human {
  Human();
}


class myClass {

  myClass(){
    print("myClass Obeject created");
  }

  void printName(String name) {
    print(name);
  }
  int Add(int a, int b) {
    int sum = a + b;
    return sum;
  }
}