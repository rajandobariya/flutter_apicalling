
import 'dart:ui';

import 'package:flutter/material.dart';

TextStyle style() {
  return TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.bold,
    color: Colors.orange,
  );
}
TextStyle style11({Color color = Colors.black, FontWeight fontWeight = FontWeight.bold}) {
  return TextStyle(
    fontSize: 20,
    fontWeight: fontWeight,
    color: color,
  );
}