import 'package:flutter/material.dart';
import 'package:flutter_tutorial/data_pass.dart';
import 'package:flutter_tutorial/ui/text_theme.dart';
import 'package:flutter_tutorial/widgets/round_btn.dart';
import 'package:flutter_tutorial/widgets/text_widget.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class SecondPage extends StatefulWidget {
  const SecondPage({super.key});

  @override
  State<SecondPage> createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {
  var no1Controller = TextEditingController();
  RangeValues values = const RangeValues(0, 100);
  var arrColor = [
    Colors.red,
    Colors.green,
    Colors.blue,
    Colors.yellow,
    Colors.orange,
    Colors.purple,
    Colors.pink,
    Colors.teal,
  ];

  callBack() {
    print("Clicked");
  }

  @override
  Widget build(BuildContext context) {
    RangeLabels labels = RangeLabels(values.start.round().toString(), values.end.round().toString());
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: Text("Flutter Demo"),
      ),
      // region -> GridView.count
      // body: GridView.count(crossAxisCount: 4,
      //   crossAxisSpacing: 11,
      //   mainAxisSpacing: 11,
      //   children: [
      //     Container(color:arrColor[0],),
      //     Container(color:arrColor[1],),
      //     Container(color:arrColor[2],),
      //     Container(color:arrColor[3],),
      //     Container(color:arrColor[4],),
      //     Container(color:arrColor[5],),
      //     Container(color:arrColor[6],),
      //     Container(color:arrColor[7],),
      //     Container(color:arrColor[8],),
      //     Container(color:arrColor[9],),
      //
      //   ]),
      // endregion
      // region -> GridView.extent
      // body: GridView.extent(maxCrossAxisExtent: 100, crossAxisSpacing:11,mainAxisSpacing: 11,children: [
      //   Container(color: arrColor[0],),
      //   Container(color: arrColor[1],),
      //   Container(color: arrColor[2],),
      //   Container(color: arrColor[3],),
      //   Container(color: arrColor[4],),
      //   Container(color: arrColor[5],),
      //   Container(color: arrColor[6],),
      //   Container(color: arrColor[7],),
      // ]),
      // endregion
      // region -> GridView.builder
      // body: GridView.builder(
      //   itemBuilder: (context, index) {
      //     return Container(
      //       color: arrColor[index],
      //     );
      //   },
      //   itemCount: arrColor.length,
      //   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
      //     crossAxisCount: 3,
      //   )
      // ),
      // endregion
      // region -> Callback Function
      // body: ElevatedButton(
      //   onPressed: callBack,
      //   child: Text("Click here!!"),
      // ),
      // endregion
      // region -> Custom Widget
      // body: Container(
      //   child: Column(
      //     children: [
      //       CatItems(),
      //       Contact(),
      //       SubCatItems(),
      //       BottomMenu(),
      //     ],
      //   ),
      // ),
      // endregion
      // region -> Stack
      // body: Container(
      //   width: 300,
      //   height: 300,
      //   child: Stack(
      //     children: [
      //       Container(width: 200,height: 200,color: Colors.blueGrey, ),
      //       Positioned(left: 21,top: 21,child: Container(width: 200,height: 200,color: Colors.grey, )),
      //     ]
      //   ),
      // ),
      // endregion
      // region -> Custom Design
      // body: Center(
      //   child: Column(
      //     mainAxisAlignment: MainAxisAlignment.start,
      //     children: [
      //       Container(
      //         width: 200,
      //         child: RoundedButton(
      //             bybName: 'Login',
      //             icon: Icon(Icons.lock),
      //             callback: () {
      //               print('Log in Clicked');
      //             },
      //             textStyle: style()),
      //       ),
      //       Container(
      //         height: 11,
      //       ),
      //       Container(
      //         width: 200,
      //         child: RoundedButton(
      //             bybName: 'Play',
      //             icon: Icon(Icons.play_arrow),
      //             callback: () {
      //               print('Play in Clicked');
      //             },
      //             bgColor: Colors.black87,
      //             textStyle: style()),
      //       ),
      //       Container(
      //         height: 11,
      //       ),
      //       Container(
      //         child: TextWidget(
      //           name: 'Hello',
      //           image: Image.asset('assets/image1.png'),
      //           bgColor: Colors.red,
      //           textStyle: TextStyle(fontSize: 14, color: Colors.white),
      //         ),
      //       ),
      //       Container(
      //         height: 11,
      //       ),
      //       Container(
      //         child: TextWidget(
      //           name: 'Rajan',
      //           image: Image.asset('assets/image2.png'),
      //           bgColor: Colors.blue,
      //           textStyle: TextStyle(fontSize: 18, color: Colors.black),
      //         ),
      //       )
      //     ],
      //   ),
      // ),
      // endregion
      // region -> Wrap Widget
      // body: Container(
      //   width: MediaQuery.of(context).size.width,
      //   height: MediaQuery.of(context).size.height,
      //   child: Wrap(
      //     alignment: WrapAlignment.spaceEvenly,
      //     direction: Axis.vertical,
      //     children: [
      //       Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.red,
      //       ),
      //       Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.green,
      //       ),
      //       Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.blue,
      //       ),
      //       Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.yellow,
      //       ),
      //       Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.orange,
      //       ),
      //       Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.purple,
      //       ),Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.red,
      //       ),
      //       Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.green,
      //       ),
      //       Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.blue,
      //       ),
      //       Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.yellow,
      //       ),
      //       Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.orange,
      //       ),
      //       Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.purple,
      //       ),Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.red,
      //       ),
      //       Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.green,
      //       ),
      //       Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.blue,
      //       ),
      //       Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.yellow,
      //       ),
      //       Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.orange,
      //       ),
      //       Container(
      //         width: 70,
      //         height: 70,
      //         color: Colors.purple,
      //       ),
      //     ]
      //   ),
      // ) ,
      // endregion
      // region -> SizeBox expand & shrink
      // body: ConstrainedBox(
      //   constraints: BoxConstraints(
      //       maxWidth: 300, minWidth: 200, minHeight: 40, maxHeight: 60),
      //   child: SizedBox.expand(
      //     child: ElevatedButton(
      //       onPressed: () {},
      //       child: Text('Click'),
      //     ),
      //   ),
      // ),

      // endregion
      // region -> SizeBox
      // body: SizedBox.square(
      //   dimension: 200,
      //   child: ElevatedButton(
      //     onPressed: () {},
      //     child: Text('Click'),
      //   ),
      // ),
      // body: Wrap(
      //   direction: Axis.vertical,
      //   children: [
      //     SizedBox.square(
      //       dimension: 100,
      //       child: ElevatedButton(
      //         onPressed: () {},
      //         child: Text('Click'),
      //       ),
      //     ),
      //     SizedBox(
      //       height: 20,
      //     ),
      //     SizedBox.square(
      //       dimension: 100,
      //       child: ElevatedButton(
      //         onPressed: () {},
      //         child: Text('Click'),
      //       ),
      //     ),
      //     SizedBox(
      //       height: 10,
      //     ),
      //     SizedBox.square(
      //       dimension: 100,
      //       child: ElevatedButton(
      //         onPressed: () {},
      //         child: Text('Click'),
      //       ),
      //     ),
      //
      //   ],
      // ),
      // endregion
      // region -> RichText
      // body: RichText(
      //   text: TextSpan(
      //     style: TextStyle(color: Colors.grey, fontSize: 20),
      //     children: [
      //       TextSpan(text: 'Hello ',),
      //       TextSpan(text: 'World!', style: TextStyle(color: Colors.blue,fontSize: 24,fontWeight: FontWeight.bold),),
      //       TextSpan(text: 'Welcome to ',),
      //       TextSpan(text: 'Flutter', style: TextStyle(color: Colors.red,fontSize: 24,fontWeight: FontWeight.bold),),
      //     ]
      //   ),
      // ),
      // endregion
      // region -> Icon
      // body: Center(child: Icon(Icons.play_circle_outline,size: 50,color: Colors.orange,)),
      // endregion
      // region -> Awesome Icon
      // body: Center(
      //     child: Row(
      //   mainAxisAlignment: MainAxisAlignment.center,
      //   children: [
      //     Icon(
      //       Icons.play_circle_outline,
      //       size: 50,
      //       color: Colors.orange,
      //     ),
      //     SizedBox(
      //       width: 10,
      //     ),
      //     FaIcon(FontAwesomeIcons.googleDrive, size: 50, color: Colors.orange),
      //   ],
      // )),
      // endregion
      // region -> Positioned
      // body: Container(
      //     width: 300,
      //     height: 200,
      //     color: Colors.blue,
      //     child: Stack(children: [
      //       Positioned(
      //         bottom: 11,
      //         left: 11,
      //
      //         child: Container(
      //           width: 100,
      //           height: 100,
      //           color: Colors.white,
      //         ),
      //       )
      //     ])),
      // endregion
      // region -> DataPass
      // body: Center(
      //   child: Container(
      //     width: 300,
      //     child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      //       Text(
      //         'DashBoard Screen',
      //         style: TextStyle(fontSize: 20),
      //       ),
      //       SizedBox(
      //         height: 10,
      //       ),
      //       TextField(
      //         controller: no1Controller,
      //       ),
      //       ElevatedButton(
      //           onPressed: () {
      //             Navigator.push(context,
      //                 MaterialPageRoute(builder: (context) => DataPass(no1Controller.text.toString())));
      //           },
      //           child: Text('My Profile')),
      //     ]),
      //   ),
      // ),
      // endregion
      // region RangeSlider
      body: Center(
          child: RangeSlider(
        values: values,
        labels: labels,
        divisions: 20,
        max: 100,
        min: 0,
        onChanged: (newValue) {
          values = newValue;
          print('${values.start},${values.end}');
          setState(() {

          });
        },
      )),
      // endregion
    );
  }
}

class CatItems extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 2,
      child: Container(
        child: ListView.builder(
          itemBuilder: (context, index) => Container(
            padding: EdgeInsets.all(10),
            width: 100,
            child: CircleAvatar(
              backgroundColor: Colors.green,
            ),
          ),
          itemCount: 10,
          scrollDirection: Axis.horizontal,
        ),
        color: Colors.red,
      ),
    );
  }
}

class Contact extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 4,
      child: Container(
          color: Colors.blue,
          child: ListView.builder(
              itemBuilder: (context, index) => ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.lightGreen,
                    ),
                    title: Text("Hello"),
                    subtitle: Text("World"),
                    trailing: Icon(Icons.add),
                  ))),
    );
  }
}

class SubCatItems extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 1,
      child: Container(
        color: Colors.purple,
        child: ListView.builder(
          itemBuilder: (context, index) => Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: 200,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.orange),
              )),
          itemCount: 10,
          scrollDirection: Axis.horizontal,
        ),
      ),
    );
  }
}

class BottomMenu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 2,
      child: Container(
        color: Colors.lightGreen,
      ),
    );
  }
}
