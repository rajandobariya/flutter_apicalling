main() {
  // var map = {
  //   "Name": "value",
  //   "YearOfExperience": 1,
  //   "Avg.Rating": 30.55,
  //   "CanLocateToOffice": true
  // };
  // map["Name"] = "ssss";


  // var mapName = Map();
  // mapName['Name'] = "ssss";
  // mapName['YearOfExperience'] = 2;
  // mapName['Avg.Rating'] = 30.55;
  // mapName['CanLocateToOffice'] = true;
  //
  //
  // print(mapName.isNotEmpty);
  // print(mapName.isEmpty);
  // print(mapName.length);
  // print(mapName.keys);
  // print(mapName.values);
  // print(mapName.containsKey('Name'));
  // print(mapName.containsValue(false));
  // print(mapName.remove('CanLocateToOffice'));
  // print(mapName);

  const name = "flutter_tutorial";


 final names = [
    "flutter",
    "Dart",
    "is",
    "awesome"
  ];
  names.add("value");
  // names = ["fluttccaer", "Dssart", "isccs", "awezzxsome"];
}
