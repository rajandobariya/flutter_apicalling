import 'package:flutter/material.dart';

class RoundedButton extends StatelessWidget {
  final String bybName;
  final Icon? icon;
  final Color bgColor;
  final TextStyle? textStyle;
  final VoidCallback? callback;

  RoundedButton(
      {required this.bybName,
      this.icon,
      this.bgColor = Colors.blue,
      this.textStyle,
      this.callback});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
        onPressed: () {
          callback!();
        },
        child: icon != null
            ? Row(
                children: [
                  icon!,
                  Text(
                    bybName,
                    style: textStyle,
                  )
                ],
              )
            : Text(
                bybName,
                style: textStyle,
              ),
        style: ElevatedButton.styleFrom(
            primary: bgColor,
            shadowColor: bgColor,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(10),
                ))));
  }
}
