
import 'package:flutter/material.dart';

class TextWidget extends StatelessWidget {
  final String name;
  final Image? image;
  final Color? bgColor;
  final TextStyle? textStyle;
  TextWidget({required this.name, required this.image, this.bgColor, this.textStyle});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 55,
      color: bgColor,
      child: image!= null?Row(
        children: [
          image!,
          Text(
            name,
            style: textStyle,
          )
        ],
      ):  Text(
        name,
        style: textStyle,)
    );
  }
}