main(){
  var a = 100;
  var b = 500;
  // if(a>200 && b>100){
  //
  //   print("Block 1");
  // }else if(a<50){
  //   print("Block 2");
  // }else if(a==80){
  //   print("Block 3");
  // }else if(a==500){
  //   print("Block 4");
  // }
  // else{
  //   print("Block else");
  // }

  if(a>200||b<100){
    print("Block 1");
  }else{
    print("Block 2");
  }
  for(var i=0;i<10;i++){
    print("Hello $i");
  }
  int no = 40;
  // do{
  //   print("Hello $no");
  //   no++;
  // }while(no<50);
  while(no<50){
    print("Hello $no");
    no++;
  }
}