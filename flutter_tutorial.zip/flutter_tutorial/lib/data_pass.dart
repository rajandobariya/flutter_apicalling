import 'package:flutter/material.dart';

class DataPass extends StatefulWidget {
  var name;
  DataPass(this.name);
  @override
  State<DataPass> createState() => _DataPassState(name);
}

class _DataPassState extends State<DataPass> {
  var name;
  _DataPassState(this.name);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: Text("My Profile"),
      ),
      body: Container(
          color: Colors.blue,
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
              name.toString(),
                  style: TextStyle(fontSize: 20, color: Colors.black),
                ),
                ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text("Back"))
              ],
            ),
          )),
    );
  }
}
