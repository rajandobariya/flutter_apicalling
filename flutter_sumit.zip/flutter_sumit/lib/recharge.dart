import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_sumit/datapass.dart';
import 'package:flutter_sumit/model/recharge.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fluttertoast/fluttertoast.dart';

class MyRecharge extends StatelessWidget {
  List<RechargeData> gridMap = [
    RechargeData(
      title: "SonyLive + Zee5 include",
      price: "\₹3662",
      dataday: "365 Days",
      image: "https://cdn-icons-png.flaticon.com/512/10588/10588535.png",
      image1: "https://cdn-icons-png.flaticon.com/512/1177/1177595.png",
      data: "2.5 GB/Day",
      other: "+3",
    ),
    RechargeData(
      title: "SonyLive + Zee5 include",
      price: "\₹666",
      dataday: "84 Days",
      image: "https://cdn-icons-png.flaticon.com/512/10588/10588535.png",
      image1: "https://cdn-icons-png.flaticon.com/512/1177/1177595.png",
      data: "2.5 GB/Day",
      other: "+5",
    ),
    RechargeData(
      title: "SonyLive + Zee5 include",
      price: "\₹2999",
      dataday: "365 Days",
      image: "https://cdn-icons-png.flaticon.com/512/10588/10588535.png",
      image1: "https://cdn-icons-png.flaticon.com/512/1177/1177595.png",
      data: "1.5 GB/Day",
      other: "+2",
    ),
    RechargeData(
      title: "SonyLive + Zee5 include",
      price: "\₹2999",
      dataday: "365 Days",
      image: "https://cdn-icons-png.flaticon.com/512/10588/10588535.png",
      image1: "https://cdn-icons-png.flaticon.com/512/1177/1177595.png",
      data: "1.5 GB/Day",
      other: "+2",
    )
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          systemOverlayStyle: SystemUiOverlayStyle(
            statusBarColor: Color(0xFF003CFF),
            statusBarIconBrightness: Brightness.light,
            statusBarBrightness: Brightness.light,
          ),
          backgroundColor: Color(0xFF003CFF),
          actions: [
            Container(
              padding: EdgeInsets.all(8),
              height: 55,
              width: MediaQuery.of(context).size.width,
              color: Color(0xFF003CFF),
              child: Row(
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child:
                        Icon(Icons.arrow_back_ios_rounded, color: Colors.white),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text(
                    "Recharge",
                    style: GoogleFonts.poppins(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: 16),
                  ),
                ],
              ),
            ),
          ],
        ),
        body: Padding(
          padding: EdgeInsets.all(8.0),
          child: ListView.builder(
            itemCount: gridMap.length,
            itemBuilder: (BuildContext context, int index) {
              return InkWell(
                onTap: () {
                  Fluttertoast.showToast(
                    msg: '$index',
                    backgroundColor: Colors.grey,
                  );
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          Datapass(rechargeData: gridMap[index]),
                    ),
                  );
                },
                child: Container(
                  padding: EdgeInsets.all(6),
                  width: MediaQuery.of(context).size.width,
                  margin: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 5,
                        blurRadius: 7,
                        offset: Offset(0, 3), // changes position of shadow
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 6, vertical: 3),
                            margin: EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: Colors.red,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10)),
                            ),
                            child: Text(
                              "Unlimited 5G",
                              style: GoogleFonts.poppins(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                fontStyle: FontStyle.italic,
                              ),
                            ),
                          ),
                          SizedBox(width: 6),
                          Text(
                            "${gridMap[index].title}".toUpperCase(),
                            style: GoogleFonts.poppins(
                              color: Colors.blueAccent,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          )
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.all(6.0),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                "${gridMap[index].price}".toUpperCase(),
                                style: GoogleFonts.poppins(
                                  color: Colors.black,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            Text(
                              "View Details",
                              style: GoogleFonts.poppins(
                                color: Colors.blueAccent,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.symmetric(horizontal: 6),
                        child: Divider(
                          color: Colors.grey,
                          thickness: 1,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 6),
                        child: Row(
                          children: [
                            Flexible(
                              flex: 1,
                              fit: FlexFit.tight,
                              child: Container(
                                margin: EdgeInsets.all(3),
                                child: Text(
                                  "validity".toUpperCase(),
                                  style: GoogleFonts.poppins(
                                    color: Colors.grey,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                            Flexible(
                              flex: 1,
                              fit: FlexFit.tight,
                              child: Container(
                                margin: EdgeInsets.all(3),
                                child: Text(
                                  "Data".toUpperCase(),
                                  style: GoogleFonts.poppins(
                                    color: Colors.grey,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                            Flexible(
                              flex: 1,
                              fit: FlexFit.tight,
                              child: Container(
                                margin: EdgeInsets.all(3),
                                child: Text(
                                  "Subcriptions".toUpperCase(),
                                  style: GoogleFonts.poppins(
                                    color: Colors.grey,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 6),
                        child: Row(
                          children: [
                            Flexible(
                              flex: 1,
                              fit: FlexFit.tight,
                              child: Container(
                                margin: EdgeInsets.all(3),
                                child: Text(
                                  "${gridMap[index].dataday}",
                                  style: GoogleFonts.poppins(
                                    color: Colors.black,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                            Flexible(
                              flex: 1,
                              fit: FlexFit.tight,
                              child: Container(
                                margin: EdgeInsets.all(3),
                                child: Text(
                                  "${gridMap[index].data}",
                                  style: GoogleFonts.poppins(
                                    color: Colors.black,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                            Flexible(
                              flex: 1,
                              fit: FlexFit.tight,
                              child: Container(
                                margin: EdgeInsets.all(3),
                                child: Stack(
                                  alignment: Alignment.centerRight,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.only(right: 30),
                                      child: Image.network(
                                        "${gridMap[index].image}",
                                        height: 25,
                                        width: 25,
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(right: 20),
                                      child: Image.network(
                                        "${gridMap[index].image1}",
                                        height: 25,
                                        width: 25,
                                      ),
                                    ),
                                    Container(
                                      height: 25,
                                      alignment: Alignment.centerRight,
                                      // alignment: Alignment.centerLeft,
                                      // margin: EdgeInsets.only(left: 40),
                                      child: Text(
                                        '${gridMap[index].other}',
                                        style: GoogleFonts.poppins(
                                            fontSize: 10,
                                            color: Colors.grey,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        height: 40,
                        margin: EdgeInsets.all(6),
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                          color: Color(0xFF003CFF),
                          borderRadius: BorderRadius.all(Radius.circular(20)),
                        ),
                        child: Center(
                          child: Text(
                            "Recharge",
                            style: GoogleFonts.poppins(
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
