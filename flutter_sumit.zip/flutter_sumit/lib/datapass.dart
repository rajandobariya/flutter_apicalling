import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sumit/model/recharge.dart';
import 'package:google_fonts/google_fonts.dart';

class Datapass extends StatelessWidget {
  final RechargeData rechargeData;

  Datapass({required this.rechargeData});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${rechargeData.data}',
              style: GoogleFonts.poppins(
                color: Colors.black,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              '${rechargeData.dataday}',
              style: GoogleFonts.poppins(
                color: Colors.black,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            Image.network(
              '${rechargeData.image1}',
              width: 50,
              height: 50,
            ),
          ],
        ),
      ),
    );
  }
}
