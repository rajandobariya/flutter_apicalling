import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class MyMenu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          systemOverlayStyle: SystemUiOverlayStyle(
            statusBarColor: Color(0xFF003CFF),
            statusBarIconBrightness: Brightness.light,
            statusBarBrightness: Brightness.light,
          ),
          backgroundColor: Color(0xFF003CFF),
          actions: [
            Container(
              padding: EdgeInsets.all(8),
              height: 55,
              width: MediaQuery.of(context).size.width,
              color: Color(0xFF003CFF),
              child: Row(children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child:
                      Icon(Icons.arrow_back_ios_rounded, color: Colors.white),
                ),
                SizedBox(
                  width: 10,
                ),
                Text("Menu",
                    style: GoogleFonts.poppins(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: 16)),
              ]),
            ),
          ],
        ),
        body: ToggleTextVisibility(),
      ),
    );
  }
}

class _ToggleTextVisibilityState extends State<ToggleTextVisibility> {
  bool isTextVisible = false;

  void toggleVisibility() {
    setState(() {
      isTextVisible = !isTextVisible;

    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.all(6.0),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(6.0),
                      child: Row(
                        children: [
                          Icon(
                            Icons.supervised_user_circle_rounded,
                            color: Color(0xFF003CFF),
                            size: 50,
                          ),
                          SizedBox(
                            width: 8,
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(right: 50),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Hi Maganbhai Saganbhai Bimjibhai FlutterWala",
                                      style: GoogleFonts.poppins(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black,
                                        fontSize: 16,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                    ),
                                    SizedBox(
                                      height: 2,
                                    ),
                                    Text(
                                      "854165164689 | Police",
                                      style: GoogleFonts.poppins(
                                        fontWeight: FontWeight.normal,
                                        color: Colors.black45,
                                        fontSize: 14,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                    ),
                                  ]),
                            ),
                          ),
                          InkWell(
                            onTap: toggleVisibility,
                            child: Icon(isTextVisible ? Icons.remove : Icons.add),
                          ),
                          SizedBox(height: 20),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.all(6),
                      child: isTextVisible
                          ? Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  height: 30,
                                  margin: EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 0),
                                  child: Text(
                                    'Profile & settings',
                                    style: GoogleFonts.poppins(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black45,
                                      fontSize: 20,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                  ),
                                ),
                                Container(
                                  height: 30,
                                  margin: EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 0),
                                  child: Text(
                                    'Profile & settings',
                                    style: GoogleFonts.poppins(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black45,
                                      fontSize: 20,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                  ),
                                ),
                                Container(
                                  height: 30,
                                  margin: EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 0),
                                  child: Text(
                                    'Profile & settings',
                                    style: GoogleFonts.poppins(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black45,
                                      fontSize: 20,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                  ),
                                ),
                                Container(
                                  height: 30,
                                  margin: EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 0),
                                  child: Text(
                                    'Profile & settings',
                                    style: GoogleFonts.poppins(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black45,
                                      fontSize: 20,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                  ),
                                ),
                                Container(
                                  height: 30,
                                  margin: EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 0),
                                  child: Text(
                                    'Profile & settings',
                                    style: GoogleFonts.poppins(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black45,
                                      fontSize: 20,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                  ),
                                ),
                              ],
                            )
                          : Container(),
                    ),
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      child: Divider(
                        color: Colors.grey,
                        thickness: 1,
                      ),
                    ),
                  ]),
            ),
          ],
        ),
      ),
    );
  }
}

class ToggleTextVisibility extends StatefulWidget {
  @override
  _ToggleTextVisibilityState createState() => _ToggleTextVisibilityState();
}
