
class RechargeData {
  final String title;
  final String price;
  final String dataday;
  final String image;
  final String image1;
  final String data;
  final String other;

  RechargeData({
    required this.title,
    required this.price,
    required this.dataday,
    required this.image,
    required this.image1,
    required this.data,
    required this.other,
  });
}
