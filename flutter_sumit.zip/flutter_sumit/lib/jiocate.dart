import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class MyJioCare extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          systemOverlayStyle: SystemUiOverlayStyle(
            statusBarColor: Color(0xFF003CFF),
            statusBarIconBrightness: Brightness.light,
            statusBarBrightness: Brightness.light,
          ),
          backgroundColor: Color(0xFF003CFF),
          actions: [
            Container(
              padding: EdgeInsets.all(8),
              height: 55,
              width: MediaQuery.of(context).size.width,
              color: Color(0xFF003CFF),
              child: Row(
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child:
                        Icon(Icons.arrow_back_ios_rounded, color: Colors.white),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text("Jio Care",
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          fontSize: 16)),
                ],
              ),
            ),
          ],
        ),
        body: Stack(
          children: [
            ListView(
              children: [
                Container(
                  height: 300,
                  child: Stack(
                    children: [
                      Image.network(
                        "https://5.imimg.com/data5/JB/FF/MY-7947811/customer-care-support-services.png",
                        height: 300,
                        width: MediaQuery.of(context).size.width,
                        fit: BoxFit.cover,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(30.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              "Hi Maganbhai\nHowe can we help?",
                              style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                  fontSize: 18),
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 30),
                              height: 40,
                              width: MediaQuery.of(context).size.width,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Center(
                                child: TextField(
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    hintText: "Type your query here",
                                    prefixIcon: Icon(Icons.search),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.all(15),
                        child: Text(
                          "Need prompt help? Check these options",
                          style: GoogleFonts.poppins(
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                              fontSize: 18),
                        ),
                      ),
                      Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.2),
                                spreadRadius: 5,
                                blurRadius: 7,
                                offset: Offset(0, 3),
                              ),
                            ],
                          ),
                          padding: EdgeInsets.all(20),
                          margin: EdgeInsets.all(15),
                          child: Row(
                            children: [
                              Icon(Icons.mic,
                                  color: Color(0xFF003CFF), size: 30),
                              SizedBox(
                                width: 8,
                              ),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Speak to HelloJio",
                                      style: GoogleFonts.poppins(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                    ),
                                    Text(
                                      "Troubleshoot with Jio Tune or Jio Care App to get help quickly and easily with Jio Tune and Jio Care. You can also use Jio Tune to get help with your Jio services.",
                                      style: GoogleFonts.poppins(
                                        fontWeight: FontWeight.normal,
                                        fontSize: 12,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 8,
                              ),
                              Icon(Icons.arrow_forward_ios_outlined,
                                  color: Color(0xFF003CFF), size: 20),
                            ],
                          )),
                      Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.2),
                                  spreadRadius: 5,
                                  blurRadius: 7,
                                  offset: Offset(0, 3),
                                )
                              ]),
                          padding: EdgeInsets.all(20),
                          margin: EdgeInsets.all(15),
                          child: Row(
                            children: [
                              Icon(Icons.chat,
                                  color: Color(0xFF003CFF), size: 30),
                              SizedBox(
                                width: 8,
                              ),
                              Expanded(
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Chat with us",
                                        style: GoogleFonts.poppins(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                      ),
                                      Text(
                                        "Troubleshoot with Jio Tune or Jio Care App to get help quickly and easily with Jio Tune and Jio Care. You can also use Jio Tune to get help with your Jio services.",
                                        style: GoogleFonts.poppins(
                                          fontWeight: FontWeight.normal,
                                          fontSize: 12,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                      ),
                                    ]),
                              ),
                              SizedBox(
                                width: 8,
                              ),
                              Icon(Icons.arrow_forward_ios_outlined,
                                  color: Color(0xFF003CFF), size: 20),
                            ],
                          )),
                      Container(
                        margin: EdgeInsets.all(15),
                        child: Text(
                          "Get quick support",
                          style: GoogleFonts.poppins(
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                              fontSize: 18),
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(6),
                        margin: EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.2),
                              spreadRadius: 5,
                              blurRadius: 7,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Flexible(
                                  flex: 1,
                                  fit: FlexFit.tight,
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: Column(
                                      children: [
                                        Container(
                                            height: 40,
                                            width: 40,
                                            decoration: BoxDecoration(
                                              color: Color(0xFFD0D7FA),
                                              borderRadius:
                                                  BorderRadius.circular(40),
                                            ),
                                            child: Icon(Icons.mic,
                                                color: Color(0xFF003CFF),
                                                size: 30)),
                                        SizedBox(
                                          height: 4,
                                        ),
                                        Text(
                                          "Express intrest for 5G",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: Colors.black45,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Flexible(
                                  flex: 1,
                                  fit: FlexFit.tight,
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: Column(
                                      children: [
                                        Container(
                                          height: 40,
                                          width: 40,
                                          decoration: BoxDecoration(
                                            color: Color(0xFFD0D7FA),
                                            borderRadius:
                                                BorderRadius.circular(40),
                                          ),
                                          child: Icon(Icons.mic,
                                              color: Color(0xFF003CFF),
                                              size: 30),
                                        ),
                                        SizedBox(
                                          height: 4,
                                        ),
                                        Text(
                                          "Express intrest for 5G",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: Colors.black45,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Flexible(
                                  flex: 1,
                                  fit: FlexFit.tight,
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: Column(
                                      children: [
                                        Container(
                                          height: 40,
                                          width: 40,
                                          decoration: BoxDecoration(
                                            color: Color(0xFFD0D7FA),
                                            borderRadius:
                                                BorderRadius.circular(40),
                                          ),
                                          child: Icon(Icons.mic,
                                              color: Color(0xFF003CFF),
                                              size: 30),
                                        ),
                                        SizedBox(
                                          height: 4,
                                        ),
                                        Text(
                                          "Express intrest for 5G",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: Colors.black45,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              children: [
                                Flexible(
                                  flex: 1,
                                  fit: FlexFit.tight,
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: Column(
                                      children: [
                                        Container(
                                          height: 40,
                                          width: 40,
                                          decoration: BoxDecoration(
                                            color: Color(0xFFD0D7FA),
                                            borderRadius:
                                                BorderRadius.circular(40),
                                          ),
                                          child: Icon(Icons.mic,
                                              color: Color(0xFF003CFF),
                                              size: 30),
                                        ),
                                        SizedBox(
                                          height: 4,
                                        ),
                                        Text(
                                          "Express intrest for 5G",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: Colors.black45,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Flexible(
                                  flex: 1,
                                  fit: FlexFit.tight,
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: Column(
                                      children: [
                                        Container(
                                            height: 40,
                                            width: 40,
                                            decoration: BoxDecoration(
                                              color: Color(0xFFD0D7FA),
                                              borderRadius:
                                                  BorderRadius.circular(40),
                                            ),
                                            child: Icon(Icons.mic,
                                                color: Color(0xFF003CFF),
                                                size: 30)),
                                        SizedBox(
                                          height: 4,
                                        ),
                                        Text(
                                          "Express intrest for 5G",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: Colors.black45,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Flexible(
                                  flex: 1,
                                  fit: FlexFit.tight,
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: Column(
                                      children: [
                                        Container(
                                          height: 40,
                                          width: 40,
                                          decoration: BoxDecoration(
                                            color: Color(0xFFD0D7FA),
                                            borderRadius:
                                                BorderRadius.circular(40),
                                          ),
                                          child: Icon(Icons.mic,
                                              color: Color(0xFF003CFF),
                                              size: 30),
                                        ),
                                        SizedBox(
                                          height: 4,
                                        ),
                                        Text(
                                          "Express intrest for 5G",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: Colors.black45,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              children: [
                                Flexible(
                                  flex: 1,
                                  fit: FlexFit.tight,
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: Column(
                                      children: [
                                        Container(
                                          height: 40,
                                          width: 40,
                                          decoration: BoxDecoration(
                                            color: Color(0xFFD0D7FA),
                                            borderRadius:
                                                BorderRadius.circular(40),
                                          ),
                                          child: Icon(Icons.mic,
                                              color: Color(0xFF003CFF),
                                              size: 30),
                                        ),
                                        SizedBox(
                                          height: 4,
                                        ),
                                        Text(
                                          "Express intrest for 5G",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: Colors.black45,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 6,
                                ),
                                Flexible(
                                  flex: 1,
                                  fit: FlexFit.tight,
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: Column(
                                      children: [
                                        Container(
                                          height: 40,
                                          width: 40,
                                          decoration: BoxDecoration(
                                            color: Color(0xFFD0D7FA),
                                            borderRadius:
                                                BorderRadius.circular(40),
                                          ),
                                          child: Icon(Icons.mic,
                                              color: Color(0xFF003CFF),
                                              size: 30),
                                        ),
                                        SizedBox(
                                          height: 4,
                                        ),
                                        Text(
                                          "Express intrest for 5G",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: Colors.black45,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 6,
                                ),
                                Flexible(
                                  flex: 1,
                                  fit: FlexFit.tight,
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Positioned(
                bottom: 0,
                right: 0,
                child: Container(
                    margin: EdgeInsets.all(15),
                    height: 65,
                    width: 65,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Color(0xFF003CFF),
                    ),
                    child: Center(
                      child: Icon(
                        Icons.mic,
                        color: Colors.white,
                        size: 30,
                      ),
                    ))),
          ],
        ),
      ),
    );
  }
}
