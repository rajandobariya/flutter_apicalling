import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class MyJioTune extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          systemOverlayStyle: SystemUiOverlayStyle(
            statusBarColor: Color(0xFF003CFF),
            statusBarIconBrightness: Brightness.light,
            statusBarBrightness: Brightness.light,
          ),
          backgroundColor: Color(0xFF003CFF),
          actions: [
            Container(
              padding: EdgeInsets.all(8),
              height: 55,
              width: MediaQuery.of(context).size.width,
              color: Color(0xFF003CFF),
              child: Row(children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child:
                      Icon(Icons.arrow_back_ios_rounded, color: Colors.white),
                ),
                SizedBox(
                  width: 10,
                ),
                Text("Jio Tune",
                    style: GoogleFonts.poppins(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: 16)),
              ]),
            ),
          ],
        ),
        body: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.all(6),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  child: Row(
                    children: [
                      Flexible(
                        child: Container(
                          margin: EdgeInsets.all(6),
                          child: ClipRRect(
                            borderRadius: BorderRadius.all(Radius.circular(4)),
                            child: Image.network(
                              "https://c.saavncdn.com/770/Leke-Prabhu-Ka-Naam-From-Tiger-3-Hindi-2023-20231023111427-500x500.jpg",
                              height: 160,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                      Flexible(
                        child: Container(
                          margin: EdgeInsets.all(6),
                          child: ClipRRect(
                            borderRadius: BorderRadius.all(Radius.circular(4)),
                            child: Image.network(
                              "https://c.saavncdn.com/155/Hua-Main-From-ANIMAL-Hindi-2023-20231011001003-500x500.jpg",
                              height: 160,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                      Flexible(
                        child: Container(
                          margin: EdgeInsets.all(6),
                          child: ClipRRect(
                            borderRadius: BorderRadius.all(Radius.circular(4)),
                            child: Image.network(
                              "https://c.saavncdn.com/139/Aankh-Micholi-Hindi-2023-20231017160518-500x500.jpg",
                              height: 160,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.all(6),
                  child: Text(
                    "Recommended Jio Tunes",
                    style: GoogleFonts.poppins(
                        color: Colors.black,
                        fontSize: 20,
                        fontWeight: FontWeight.w700),
                  ),
                ),
                Container(
                  height: 138,
                  width: MediaQuery.of(context).size.width,
                  child: ListView(scrollDirection: Axis.horizontal, children: [
                    Row(children: [
                      Container(
                        width: 100,
                        margin:
                            EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                        child: Column(
                          children: [
                            ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: Image.network(
                                  "https://c.saavncdn.com/editorial/logo/TimelessGhazals_20211215062059_500x500.jpg",
                                  height: 100,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.cover,
                                )),
                            SizedBox(
                              height: 6,
                            ),
                            Text(
                              "The Sound of Rajan",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.poppins(
                                  fontSize: 14, color: Colors.black),
                            )
                          ],
                        ),
                      ),
                      Container(
                        width: 100,
                        margin:
                            EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                        child: Column(
                          children: [
                            ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: Image.network(
                                  "https://c.saavncdn.com/editorial/OnlyKhushiyaan_20230701031906_500x500.jpg",
                                  height: 100,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.cover,
                                )),
                            SizedBox(
                              height: 6,
                            ),
                            Text(
                              "The Sound of Rajan",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.poppins(
                                  fontSize: 14, color: Colors.black),
                            )
                          ],
                        ),
                      ),
                      Container(
                        width: 100,
                        margin:
                            EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                        child: Column(
                          children: [
                            ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: Image.network(
                                  "https://c.saavncdn.com/editorial/ChillMaaro_20230701031848_500x500.jpg",
                                  height: 100,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.cover,
                                )),
                            SizedBox(
                              height: 6,
                            ),
                            Text(
                              "The Sound of Rajan",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.poppins(
                                  fontSize: 14, color: Colors.black),
                            )
                          ],
                        ),
                      ),
                      Container(
                        width: 100,
                        margin:
                            EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                        child: Column(
                          children: [
                            ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: Image.network(
                                  "https://c.saavncdn.com/editorial/CheerForIndiaHindi_20230829142914_500x500.jpg",
                                  height: 100,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.cover,
                                )),
                            SizedBox(
                              height: 6,
                            ),
                            Text(
                              "The Sound of Rajan",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.poppins(
                                  fontSize: 14, color: Colors.black),
                            )
                          ],
                        ),
                      ),
                      Container(
                        width: 100,
                        margin:
                            EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                        child: Column(
                          children: [
                            ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: Image.network(
                                  "https://c.saavncdn.com/editorial/BestOf2000sHindi_20230901051004_500x500.jpg",
                                  height: 100,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.cover,
                                )),
                            SizedBox(
                              height: 6,
                            ),
                            Text(
                              "The Sound of Rajan",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.poppins(
                                  fontSize: 14, color: Colors.black),
                            )
                          ],
                        ),
                      ),
                      Container(
                        width: 100,
                        margin:
                            EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                        child: Column(
                          children: [
                            ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: Image.network(
                                  "https://c.saavncdn.com/editorial/MenInIndipop-NewHits_20231013190219_500x500.jpg",
                                  height: 100,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.cover,
                                )),
                            SizedBox(
                              height: 6,
                            ),
                            Text(
                              "The Sound of Rajan",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.poppins(
                                  fontSize: 14, color: Colors.black),
                            )
                          ],
                        ),
                      ),
                      Container(
                        width: 100,
                        margin:
                            EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                        child: Column(
                          children: [
                            ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: Image.network(
                                  "https://c.saavncdn.com/editorial/JhakaasRemakes_20230404064405_500x500.jpg",
                                  height: 100,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.cover,
                                )),
                            SizedBox(
                              height: 6,
                            ),
                            Text(
                              "The Sound of Rajan",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.poppins(
                                  fontSize: 14, color: Colors.black),
                            )
                          ],
                        ),
                      ),
                      Container(
                        width: 100,
                        margin:
                            EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                        child: Column(
                          children: [
                            ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: Image.network(
                                  "https://c.saavncdn.com/editorial/MostStreamedLoveSongs-Hindi_20231004025945_500x500.jpg",
                                  height: 100,
                                  width: MediaQuery.of(context).size.width,
                                  fit: BoxFit.cover,
                                )),
                            SizedBox(
                              height: 6,
                            ),
                            Text(
                              "The Sound of Rajan",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.poppins(
                                  fontSize: 14, color: Colors.black),
                            )
                          ],
                        ),
                      ),
                    ]),
                  ]),
                ),
                Container(
                  margin: EdgeInsets.all(6),
                  child: Text(
                    "Trending Jio Tunes",
                    style: GoogleFonts.poppins(
                        color: Colors.black,
                        fontSize: 20,
                        fontWeight: FontWeight.w700),
                  ),
                ),
                Container(
                  height: 180,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      Container(
                        margin: EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 6,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    "https://99designs-blog.imgix.net/blog/wp-content/uploads/2018/02/attachment_92114614-e1519200174268.jpg?auto=format&q=60&fit=max&w=930",
                                    width: 50,
                                    height: 50,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  "Tum Hi Ho",
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.black),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                )
                              ],
                            ),
                            SizedBox(height: 6),
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    "https://99designs-blog.imgix.net/blog/wp-content/uploads/2018/02/attachment_92114614-e1519200174268.jpg?auto=format&q=60&fit=max&w=930",
                                    width: 50,
                                    height: 50,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  "Tum Hi Ho",
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.black),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                )
                              ],
                            ),
                            SizedBox(height: 6),
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    "https://99designs-blog.imgix.net/blog/wp-content/uploads/2018/02/attachment_92114614-e1519200174268.jpg?auto=format&q=60&fit=max&w=930",
                                    width: 50,
                                    height: 50,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  "Tum Hi Ho",
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.black),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                )
                              ],
                            ),
                            SizedBox(height: 6),
                          ],
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.all(6),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    "https://99designs-blog.imgix.net/blog/wp-content/uploads/2018/02/attachment_92114614-e1519200174268.jpg?auto=format&q=60&fit=max&w=930",
                                    width: 50,
                                    height: 50,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  "Tum Hi Ho",
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.black),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                )
                              ],
                            ),
                            SizedBox(height: 6),
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    "https://99designs-blog.imgix.net/blog/wp-content/uploads/2018/02/attachment_92114614-e1519200174268.jpg?auto=format&q=60&fit=max&w=930",
                                    width: 50,
                                    height: 50,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  "Tum Hi Ho",
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.black),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                )
                              ],
                            ),
                            SizedBox(height: 6),
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    "https://99designs-blog.imgix.net/blog/wp-content/uploads/2018/02/attachment_92114614-e1519200174268.jpg?auto=format&q=60&fit=max&w=930",
                                    width: 50,
                                    height: 50,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  "Tum Hi Ho",
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.black),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                )
                              ],
                            ),
                            SizedBox(height: 6),
                          ],
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.all(6),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    "https://99designs-blog.imgix.net/blog/wp-content/uploads/2018/02/attachment_92114614-e1519200174268.jpg?auto=format&q=60&fit=max&w=930",
                                    width: 50,
                                    height: 50,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  "Tum Hi Ho",
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.black),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                )
                              ],
                            ),
                            SizedBox(height: 6),
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    "https://99designs-blog.imgix.net/blog/wp-content/uploads/2018/02/attachment_92114614-e1519200174268.jpg?auto=format&q=60&fit=max&w=930",
                                    width: 50,
                                    height: 50,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  "Tum Hi Ho",
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.black),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                )
                              ],
                            ),
                            SizedBox(height: 6),
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    "https://99designs-blog.imgix.net/blog/wp-content/uploads/2018/02/attachment_92114614-e1519200174268.jpg?auto=format&q=60&fit=max&w=930",
                                    width: 50,
                                    height: 50,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  "Tum Hi Ho",
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.black),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                )
                              ],
                            ),
                            SizedBox(height: 6),
                          ],
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.all(6),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    "https://99designs-blog.imgix.net/blog/wp-content/uploads/2018/02/attachment_92114614-e1519200174268.jpg?auto=format&q=60&fit=max&w=930",
                                    width: 50,
                                    height: 50,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  "Tum Hi Ho",
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.black),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                )
                              ],
                            ),
                            SizedBox(height: 6),
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    "https://99designs-blog.imgix.net/blog/wp-content/uploads/2018/02/attachment_92114614-e1519200174268.jpg?auto=format&q=60&fit=max&w=930",
                                    width: 50,
                                    height: 50,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  "Tum Hi Ho",
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.black),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                )
                              ],
                            ),
                            SizedBox(height: 6),
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(5),
                                  child: Image.network(
                                    "https://99designs-blog.imgix.net/blog/wp-content/uploads/2018/02/attachment_92114614-e1519200174268.jpg?auto=format&q=60&fit=max&w=930",
                                    width: 50,
                                    height: 50,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  "Tum Hi Ho",
                                  style: TextStyle(
                                      fontSize: 14, color: Colors.black),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                )
                              ],
                            ),
                            SizedBox(height: 6),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.all(6),
                  child: Text(
                    "Top Jio Tunes",
                    style: GoogleFonts.poppins(
                        color: Colors.black,
                        fontSize: 20,
                        fontWeight: FontWeight.w700),
                  ),
                ),
                Container(
                  height: 138,
                  width: MediaQuery.of(context).size.width,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 100,
                            margin: EdgeInsets.symmetric(
                                horizontal: 6, vertical: 6),
                            child: Column(
                              children: [
                                ClipRRect(
                                    borderRadius: BorderRadius.circular(6),
                                    child: Image.network(
                                      "https://c.saavncdn.com/editorial/logo/TimelessGhazals_20211215062059_500x500.jpg",
                                      height: 100,
                                      width: MediaQuery.of(context).size.width,
                                      fit: BoxFit.cover,
                                    )),
                                SizedBox(
                                  height: 6,
                                ),
                                Text(
                                  "The Sound of Rajan",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.poppins(
                                      fontSize: 14, color: Colors.black),
                                )
                              ],
                            ),
                          ),
                          Container(
                            width: 100,
                            margin: EdgeInsets.symmetric(
                                horizontal: 6, vertical: 6),
                            child: Column(
                              children: [
                                ClipRRect(
                                    borderRadius: BorderRadius.circular(6),
                                    child: Image.network(
                                      "https://c.saavncdn.com/editorial/OnlyKhushiyaan_20230701031906_500x500.jpg",
                                      height: 100,
                                      width: MediaQuery.of(context).size.width,
                                      fit: BoxFit.cover,
                                    )),
                                SizedBox(
                                  height: 6,
                                ),
                                Text(
                                  "The Sound of Rajan",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.poppins(
                                      fontSize: 14, color: Colors.black),
                                )
                              ],
                            ),
                          ),
                          Container(
                            width: 100,
                            margin: EdgeInsets.symmetric(
                                horizontal: 6, vertical: 6),
                            child: Column(
                              children: [
                                ClipRRect(
                                    borderRadius: BorderRadius.circular(6),
                                    child: Image.network(
                                      "https://c.saavncdn.com/editorial/ChillMaaro_20230701031848_500x500.jpg",
                                      height: 100,
                                      width: MediaQuery.of(context).size.width,
                                      fit: BoxFit.cover,
                                    )),
                                SizedBox(
                                  height: 6,
                                ),
                                Text(
                                  "The Sound of Rajan",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.poppins(
                                      fontSize: 14, color: Colors.black),
                                )
                              ],
                            ),
                          ),
                          Container(
                            width: 100,
                            margin: EdgeInsets.symmetric(
                                horizontal: 6, vertical: 6),
                            child: Column(
                              children: [
                                ClipRRect(
                                    borderRadius: BorderRadius.circular(6),
                                    child: Image.network(
                                      "https://c.saavncdn.com/editorial/CheerForIndiaHindi_20230829142914_500x500.jpg",
                                      height: 100,
                                      width: MediaQuery.of(context).size.width,
                                      fit: BoxFit.cover,
                                    )),
                                SizedBox(
                                  height: 6,
                                ),
                                Text(
                                  "The Sound of Rajan",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.poppins(
                                      fontSize: 14, color: Colors.black),
                                )
                              ],
                            ),
                          ),
                          Container(
                            width: 100,
                            margin: EdgeInsets.symmetric(
                                horizontal: 6, vertical: 6),
                            child: Column(
                              children: [
                                ClipRRect(
                                    borderRadius: BorderRadius.circular(6),
                                    child: Image.network(
                                      "https://c.saavncdn.com/editorial/BestOf2000sHindi_20230901051004_500x500.jpg",
                                      height: 100,
                                      width: MediaQuery.of(context).size.width,
                                      fit: BoxFit.cover,
                                    )),
                                SizedBox(
                                  height: 6,
                                ),
                                Text(
                                  "The Sound of Rajan",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.poppins(
                                      fontSize: 14, color: Colors.black),
                                )
                              ],
                            ),
                          ),
                          Container(
                            width: 100,
                            margin: EdgeInsets.symmetric(
                                horizontal: 6, vertical: 6),
                            child: Column(
                              children: [
                                ClipRRect(
                                    borderRadius: BorderRadius.circular(6),
                                    child: Image.network(
                                      "https://c.saavncdn.com/editorial/MenInIndipop-NewHits_20231013190219_500x500.jpg",
                                      height: 100,
                                      width: MediaQuery.of(context).size.width,
                                      fit: BoxFit.cover,
                                    )),
                                SizedBox(
                                  height: 6,
                                ),
                                Text(
                                  "The Sound of Rajan",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.poppins(
                                      fontSize: 14, color: Colors.black),
                                )
                              ],
                            ),
                          ),
                          Container(
                            width: 100,
                            margin: EdgeInsets.symmetric(
                                horizontal: 6, vertical: 6),
                            child: Column(
                              children: [
                                ClipRRect(
                                    borderRadius: BorderRadius.circular(6),
                                    child: Image.network(
                                      "https://c.saavncdn.com/editorial/JhakaasRemakes_20230404064405_500x500.jpg",
                                      height: 100,
                                      width: MediaQuery.of(context).size.width,
                                      fit: BoxFit.cover,
                                    )),
                                SizedBox(
                                  height: 6,
                                ),
                                Text(
                                  "The Sound of Rajan",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.poppins(
                                      fontSize: 14, color: Colors.black),
                                )
                              ],
                            ),
                          ),
                          Container(
                            width: 100,
                            margin: EdgeInsets.symmetric(
                                horizontal: 6, vertical: 6),
                            child: Column(
                              children: [
                                ClipRRect(
                                    borderRadius: BorderRadius.circular(6),
                                    child: Image.network(
                                      "https://c.saavncdn.com/editorial/MostStreamedLoveSongs-Hindi_20231004025945_500x500.jpg",
                                      height: 100,
                                      width: MediaQuery.of(context).size.width,
                                      fit: BoxFit.cover,
                                    )),
                                SizedBox(
                                  height: 6,
                                ),
                                Text(
                                  "The Sound of Rajan",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.poppins(
                                      fontSize: 14, color: Colors.black),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
