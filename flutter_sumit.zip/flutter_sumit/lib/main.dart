import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter_sumit/jiocate.dart';
import 'package:flutter_sumit/jiotune.dart';
import 'package:flutter_sumit/menu.dart';
import 'package:flutter_sumit/recharge.dart';
import 'package:flutter_sumit/splash.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'My Jio App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Color(0xFF003CFF)),
        useMaterial3: true,
      ),
      home: SplashScreen(),
    );
  }
}

class MyHome1Page extends StatefulWidget {
  const MyHome1Page({super.key});

  @override
  State<MyHome1Page> createState() => _MyMyHome2PageState();
}

class _MyMyHome2PageState extends State<MyHome1Page> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        systemOverlayStyle: SystemUiOverlayStyle(
          statusBarColor: Color(0xFF003CFF),
          statusBarIconBrightness: Brightness.light,
          statusBarBrightness: Brightness.light,
        ),
        backgroundColor: Color(0xFF003CFF),
        actions: [
          Container(
              height: 55,
              width: MediaQuery.of(context).size.width,
              color: Color(0xFF003CFF),
              child: Row(children: [
                Flexible(
                  flex: 2,
                  fit: FlexFit.tight,
                  child: Container(
                    child: Container(
                      margin: EdgeInsets.symmetric(horizontal: 10),
                      height: 40,
                      decoration: BoxDecoration(
                        color: Colors.black38,
                        borderRadius: BorderRadius.circular(40),
                      ),
                      padding: EdgeInsets.all(8),
                      child: TextField(
                        cursorColor: Colors.white,
                        autofocus: false,
                        textInputAction: TextInputAction.search,
                        decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "Search",
                            hintStyle: GoogleFonts.poppins(
                              color: Colors.white,
                              fontSize: 16,
                            )),
                        style: GoogleFonts.poppins(
                            color: Colors.white, fontSize: 16),
                      ),
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 10),
                      child: (Icon(
                        Icons.mic,
                        color: Colors.white,
                      )),
                    ),
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 10),
                      child: (Icon(
                        Icons.document_scanner,
                        color: Colors.white,
                      )),
                    ),
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 10),
                      child: (Icon(
                        Icons.notification_add,
                        color: Colors.white,
                      )),
                    ),
                  ],
                ),
              ])),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(children: [
              Container(
                padding: EdgeInsets.all(8),
                width: MediaQuery.of(context).size.width,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Flexible(
                            flex: 1,
                            fit: FlexFit.tight,
                            child: Column(children: [
                              Container(
                                  height: 50,
                                  width: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50),
                                    color: Color(0xFF003CFF),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Image.network(
                                      "https://cdn-icons-png.flaticon.com/512/1551/1551353.png",
                                      color: Colors.white,
                                    ),
                                  )),
                              SizedBox(
                                height: 3,
                              ),
                              Text(
                                "Mobile",
                                style: GoogleFonts.poppins(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                                textAlign: TextAlign.center,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ]),
                          ),
                          Flexible(
                            flex: 1,
                            fit: FlexFit.tight,
                            child: Column(children: [
                              Container(
                                  height: 50,
                                  width: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50),
                                    color: Color(0xFF003CFF),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Image.network(
                                      "https://cdn-icons-png.flaticon.com/512/2876/2876838.png",
                                      color: Colors.white,
                                    ),
                                  )),
                              SizedBox(
                                height: 3,
                              ),
                              Text(
                                "Fiber",
                                style: GoogleFonts.poppins(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                                textAlign: TextAlign.center,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ]),
                          ),
                          Flexible(
                            flex: 1,
                            fit: FlexFit.tight,
                            child: Column(children: [
                              Container(
                                  height: 50,
                                  width: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50),
                                    color: Color(0xFF8AC5BA),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Image.network(
                                      "https://cdn-icons-png.flaticon.com/512/876/876817.png",
                                      color: Colors.white,
                                    ),
                                  )),
                              SizedBox(
                                height: 3,
                              ),
                              Text(
                                "Music",
                                style: GoogleFonts.poppins(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                                textAlign: TextAlign.center,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ]),
                          ),
                          Flexible(
                            flex: 1,
                            fit: FlexFit.tight,
                            child: Column(children: [
                              Container(
                                  height: 50,
                                  width: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50),
                                    color: Color(0xFF750000),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Image.network(
                                      "https://cdn-icons-png.flaticon.com/512/11632/11632561.png",
                                      color: Colors.white,
                                    ),
                                  )),
                              SizedBox(
                                height: 3,
                              ),
                              Text(
                                "Live TV",
                                style: GoogleFonts.poppins(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                                textAlign: TextAlign.center,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ]),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 8,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Flexible(
                            flex: 1,
                            fit: FlexFit.tight,
                            child: Column(children: [
                              Container(
                                  height: 50,
                                  width: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50),
                                    color: Color(0xFFFF0000),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Image.network(
                                      "https://cdn-icons-png.flaticon.com/512/9001/9001771.png",
                                      color: Colors.white,
                                    ),
                                  )),
                              SizedBox(
                                height: 3,
                              ),
                              Text(
                                "Shop",
                                style: GoogleFonts.poppins(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                                textAlign: TextAlign.center,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ]),
                          ),
                          Flexible(
                            flex: 1,
                            fit: FlexFit.tight,
                            child: Column(children: [
                              Container(
                                  height: 50,
                                  width: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50),
                                    color: Color(0xFF003CFF),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Image.network(
                                      "https://cdn-icons-png.flaticon.com/512/9777/9777804.png",
                                      color: Colors.white,
                                    ),
                                  )),
                              SizedBox(
                                height: 3,
                              ),
                              Text(
                                "UPI",
                                style: GoogleFonts.poppins(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                                textAlign: TextAlign.center,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ]),
                          ),
                          Flexible(
                            flex: 1,
                            fit: FlexFit.tight,
                            child: Column(children: [
                              Container(
                                  height: 50,
                                  width: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50),
                                    color: Color(0xFF1E9F55),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Image.network(
                                      "https://cdn-icons-png.flaticon.com/512/3743/3743233.png",
                                      color: Colors.white,
                                    ),
                                  )),
                              SizedBox(
                                height: 3,
                              ),
                              Text(
                                "Games",
                                style: GoogleFonts.poppins(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                                textAlign: TextAlign.center,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ]),
                          ),
                          Flexible(
                            flex: 1,
                            fit: FlexFit.tight,
                            child: Column(children: [
                              Container(
                                  height: 50,
                                  width: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50),
                                    color: Color(0xFF8C0606),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Image.network(
                                      "https://cdn-icons-png.flaticon.com/512/12328/12328936.png",
                                      color: Colors.white,
                                    ),
                                  )),
                              SizedBox(
                                height: 3,
                              ),
                              Text(
                                "News",
                                style: GoogleFonts.poppins(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                                textAlign: TextAlign.center,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ]),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 8,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Flexible(
                            flex: 1,
                            fit: FlexFit.tight,
                            child: Column(children: [
                              Container(
                                  height: 50,
                                  width: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50),
                                    color: Color(0xFF6AC9C2),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Image.network(
                                      "https://cdn-icons-png.flaticon.com/512/152/152810.png",
                                      color: Colors.white,
                                    ),
                                  )),
                              SizedBox(
                                height: 3,
                              ),
                              Text(
                                "Shorts",
                                style: GoogleFonts.poppins(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                                textAlign: TextAlign.center,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ]),
                          ),
                          Flexible(
                            flex: 1,
                            fit: FlexFit.tight,
                            child: Column(children: [
                              Container(
                                  height: 50,
                                  width: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50),
                                    color: Color(0xFF003CFF),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Image.network(
                                      "https://cdn-icons-png.flaticon.com/512/9720/9720911.png",
                                      color: Colors.white,
                                    ),
                                  )),
                              SizedBox(
                                height: 3,
                              ),
                              Text(
                                "eLearning",
                                style: GoogleFonts.poppins(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                                textAlign: TextAlign.center,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ]),
                          ),
                          Flexible(
                            flex: 1,
                            fit: FlexFit.tight,
                            child: Column(children: [
                              Container(
                                  height: 50,
                                  width: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50),
                                    color: Color(0xFF9900FF),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Image.network(
                                      "https://cdn-icons-png.flaticon.com/512/11824/11824234.png",
                                      color: Colors.white,
                                    ),
                                  )),
                              SizedBox(
                                height: 3,
                              ),
                              Text(
                                "Play&Win",
                                style: GoogleFonts.poppins(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                                textAlign: TextAlign.center,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ]),
                          ),
                          Flexible(
                            flex: 1,
                            fit: FlexFit.tight,
                            child: Column(children: [
                              Container(
                                  height: 50,
                                  width: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50),
                                    color: Color(0xFFDAE7FF),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(15),
                                    child: Image.network(
                                      "https://cdn-icons-png.flaticon.com/512/271/271210.png",
                                      color: Color(0xFF003CFF),
                                    ),
                                  )),
                              SizedBox(
                                height: 3,
                              ),
                              Text(
                                "More",
                                style: GoogleFonts.poppins(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                                textAlign: TextAlign.center,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            ]),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 8,
                    ),
                    CarouselSlider(
                      options: CarouselOptions(height: 180.0),
                      items: [
                        "https://assets.mspimages.in/gear/wp-content/uploads/2021/09/Jio-logo-new.jpg",
                        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-mp6yTTMNVhKcFGQb7IQ7EI2MYl5cmkHthQkfnBP64iNUAsPuAGZuso_2ItGShZXkXBs&usqp=CAU",
                        "https://assets.mspimages.in/gear/wp-content/uploads/2021/09/Jio-logo-new.jpg",
                        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRvn-KBTYx_brS-9fqFeqqbOav5suZaVsxdtALAmBq6GZNSZq7e9ckHxoXkhctW5tcEIQ8&usqp=CAU",
                        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-mp6yTTMNVhKcFGQb7IQ7EI2MYl5cmkHthQkfnBP64iNUAsPuAGZuso_2ItGShZXkXBs&usqp=CAU",
                      ].map((i) {
                        return Builder(
                          builder: (BuildContext context) {
                            return Container(
                              width: MediaQuery.of(context).size.width,
                              margin: EdgeInsets.all(8),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(30.0),
                                // Set the corner radius as desired
                                child: Image.network(
                                  '$i',
                                  fit: BoxFit
                                      .cover, // You can use BoxFit.cover or other options based on your needs
                                ),
                              ),
                            );
                          },
                        );
                      }).toList(),
                    ),
                    Container(
                      padding:
                          EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                      margin: EdgeInsets.only(
                          top: 16, bottom: 8, left: 26, right: 26),
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            spreadRadius: 5,
                            blurRadius: 7,
                            offset: Offset(0, 3), // changes position of shadow
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.mobile_screen_share_rounded,
                                color: Color(0xFF003CFF),
                              ),
                              SizedBox(width: 10),
                              Expanded(
                                  child: Text(
                                "Mobile prepaid 9988558254",
                                style: GoogleFonts.poppins(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              )),
                              // Spacer(), // This will push the icon to the rightmost side
                              Icon(
                                size: 20,
                                Icons.arrow_forward_ios_outlined,
                                color: Color(0xFF003CFF),
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Flexible(
                                flex: 1,
                                fit: FlexFit.tight,
                                child: Container(
                                  height: 86,
                                  padding: EdgeInsets.all(6),
                                  child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Data",
                                          style: GoogleFonts.poppins(
                                              color: Colors.grey, fontSize: 12),
                                        ),
                                        Text(
                                          "1.12 GB",
                                          style: GoogleFonts.poppins(
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 16),
                                        ),
                                        Text(
                                          "left of 1.50 GB",
                                          style: GoogleFonts.poppins(
                                              color: Colors.grey, fontSize: 12),
                                        ),
                                        Text(
                                          "Renews in 10 hours",
                                          style: GoogleFonts.poppins(
                                              color: Colors.grey, fontSize: 12),
                                        ),
                                      ]),
                                ),
                              ),
                              Container(
                                width: 1,
                                height: 86,
                                color: Colors.black12,
                              ),
                              Flexible(
                                flex: 1,
                                fit: FlexFit.tight,
                                child: Container(
                                  height: 86,
                                  margin: EdgeInsets.only(left: 12),
                                  padding: EdgeInsets.all(6),
                                  child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Plan",
                                          style: GoogleFonts.poppins(
                                              color: Colors.grey, fontSize: 12),
                                        ),
                                        Text(
                                          "₹ 666",
                                          style: GoogleFonts.poppins(
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 16),
                                        ),
                                        Text(
                                          "57 days left",
                                          style: GoogleFonts.poppins(
                                              color: Colors.grey, fontSize: 12),
                                        ),
                                      ]),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          Row(
                            children: [
                              Flexible(
                                flex: 2,
                                fit: FlexFit.tight,
                                child: Container(
                                  margin: EdgeInsets.symmetric(horizontal: 3),
                                  decoration: BoxDecoration(
                                    border: Border.all(color: Colors.black12),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  height: 40,
                                  child: Center(
                                    child: Text(
                                      "View Plan",
                                      style: GoogleFonts.poppins(
                                          color: Color(0xFF003CFF),
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14),
                                    ),
                                  ),
                                ),
                              ),
                              Flexible(
                                flex: 3,
                                fit: FlexFit.tight,
                                child: Container(
                                  margin: EdgeInsets.symmetric(horizontal: 3),
                                  decoration: BoxDecoration(
                                    color: Color(0xFF003CFF),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  height: 40,
                                  child: Center(
                                    child: Text(
                                      "Recharge",
                                      style: GoogleFonts.poppins(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 13),
                                    ),
                                  ),
                                ),
                              ),
                              // Add more widgets here if needed
                            ],
                          )
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(16),
                      margin: EdgeInsets.only(
                          top: 16, bottom: 8, left: 26, right: 26),
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.4),
                            spreadRadius: 5,
                            blurRadius: 7,
                            offset: Offset(0, 3), // changes position of shadow
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(
                                  child: Text(
                                "JioFiber, Live TV & more",
                                style: GoogleFonts.poppins(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              )),
                              // Spacer(), // This will push the icon to the rightmost side
                              Text(
                                "Explore Now",
                                style: GoogleFonts.poppins(
                                  color: Color(0xFF003CFF),
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 14),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 30),
                      child: Text(
                        "Trending now",
                        style: GoogleFonts.poppins(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(16),
                      margin: EdgeInsets.only(
                          top: 16, bottom: 8, left: 26, right: 26),
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.4),
                            spreadRadius: 5,
                            blurRadius: 7,
                            offset: Offset(0, 3), // changes position of shadow
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Flexible(
                                flex: 1,
                                fit: FlexFit.tight,
                                child: Column(children: [
                                  Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(50),
                                        color: Color(0xFFCBD3EF),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(12),
                                        child: Image.network(
                                          "https://cdn-icons-png.flaticon.com/512/9068/9068173.png",
                                          color: Color(0xFF003CFF),
                                        ),
                                      )),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text(
                                    "Usage details",
                                    style: GoogleFonts.poppins(
                                      color: Colors.black,
                                      fontWeight: FontWeight.normal,
                                      fontSize: 12,
                                    ),
                                    textAlign: TextAlign.center,
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                  ),
                                ]),
                              ),
                              Flexible(
                                flex: 1,
                                fit: FlexFit.tight,
                                child: Column(children: [
                                  Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(50),
                                        color: Color(0xFFCBD3EF),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(12),
                                        child: Image.network(
                                          "https://cdn-icons-png.flaticon.com/512/938/938830.png",
                                          color: Color(0xFF003CFF),
                                        ),
                                      )),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text(
                                    "Recharge for a friends",
                                    style: GoogleFonts.poppins(
                                      color: Colors.black,
                                      fontWeight: FontWeight.normal,
                                      fontSize: 12,
                                    ),
                                    textAlign: TextAlign.center,
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                  ),
                                ]),
                              ),
                              Flexible(
                                flex: 1,
                                fit: FlexFit.tight,
                                child: Column(children: [
                                  Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(50),
                                        color: Color(0xFFCBD3EF),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(12),
                                        child: Image.network(
                                          "https://cdn-icons-png.flaticon.com/512/831/831337.png",
                                          color: Color(0xFF003CFF),
                                        ),
                                      )),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text(
                                    "Jio Tune",
                                    style: GoogleFonts.poppins(
                                      color: Colors.black,
                                      fontWeight: FontWeight.normal,
                                      fontSize: 12,
                                    ),
                                    textAlign: TextAlign.center,
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                  ),
                                ]),
                              ),
                            ],
                          ),
                          SizedBox(height: 15),
                          Row(
                            children: [
                              Flexible(
                                flex: 1,
                                fit: FlexFit.tight,
                                child: Column(children: [
                                  Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(50),
                                        color: Color(0xFFCBD3EF),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(12),
                                        child: Image.network(
                                          "https://cdn-icons-png.flaticon.com/512/3215/3215085.png",
                                          color: Color(0xFF003CFF),
                                        ),
                                      )),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text(
                                    "GetJioAirFiber",
                                    style: GoogleFonts.poppins(
                                      color: Colors.black,
                                      fontWeight: FontWeight.normal,
                                      fontSize: 12,
                                    ),
                                    textAlign: TextAlign.center,
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                  ),
                                ]),
                              ),
                              Flexible(
                                flex: 1,
                                fit: FlexFit.tight,
                                child: Column(children: [
                                  Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(50),
                                        color: Color(0xFFCBD3EF),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(12),
                                        child: Image.network(
                                          "https://cdn-icons-png.flaticon.com/512/2975/2975089.png",
                                          color: Color(0xFF003CFF),
                                        ),
                                      )),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text(
                                    "Get JioFiber",
                                    style: GoogleFonts.poppins(
                                      color: Colors.black,
                                      fontWeight: FontWeight.normal,
                                      fontSize: 12,
                                    ),
                                    textAlign: TextAlign.center,
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                  ),
                                ]),
                              ),
                              Flexible(
                                flex: 1,
                                fit: FlexFit.tight,
                                child: Column(children: [
                                  Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(50),
                                        color: Color(0xFFCBD3EF),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(12),
                                        child: Image.network(
                                          "https://cdn-icons-png.flaticon.com/512/8408/8408011.png",
                                          color: Color(0xFF003CFF),
                                        ),
                                      )),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text(
                                    "Get JioSim",
                                    style: GoogleFonts.poppins(
                                      color: Colors.black,
                                      fontWeight: FontWeight.normal,
                                      fontSize: 12,
                                    ),
                                    textAlign: TextAlign.center,
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                  ),
                                ]),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ]),
          ),
          Container(
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.4),
                    spreadRadius: 5,
                    blurRadius: 7,
                    offset: Offset(0, 3), // changes position of shadow
                  )
                ]),
            width: MediaQuery.of(context).size.width,
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  InkWell(
                    onTap: () {
                    },
                    child: Container(
                      child: Column(
                        children: [
                          Image.network(
                              "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bf/Reliance_Jio_Logo.svg/240px-Reliance_Jio_Logo.svg.png",
                              height: 30,
                              width: 30),
                          SizedBox(height: 3),
                          Text(
                            "MyJio",
                            style: GoogleFonts.poppins(
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => MyRecharge(),
                          ));
                    },
                    child: Column(
                      children: [
                        Image.network(
                          "https://cdn-icons-png.flaticon.com/512/2769/2769441.png",
                          height: 30,
                          width: 30,
                          color: Colors.grey,
                        ),
                        SizedBox(height: 3),
                        Text(
                          "Recharge",
                          style: GoogleFonts.poppins(
                            color: Colors.grey,
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => MyJioTune(),
                          ));
                    },
                    child: Column(
                      children: [
                        Image.network(
                          "https://cdn-icons-png.flaticon.com/512/9899/9899057.png",
                          height: 30,
                          width: 30,
                          color: Colors.grey,
                        ),
                        SizedBox(height: 3),
                        Text(
                          "JioTunes",
                          style: GoogleFonts.poppins(
                            color: Colors.grey,
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => MyJioCare(),
                          ));
                    },
                    child: Column(
                      children: [
                        Image.network(
                          "https://cdn-icons-png.flaticon.com/512/3249/3249904.png",
                          height: 30,
                          width: 30,
                          color: Colors.grey,
                        ),
                        SizedBox(height: 3),
                        Text(
                          "JioCare",
                          style: GoogleFonts.poppins(
                            color: Colors.grey,
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => MyMenu(),
                          ));
                    },
                    child: Column(
                      children: [
                        Image.network(
                          "https://cdn-icons-png.flaticon.com/512/5358/5358649.png",
                          height: 30,
                          width: 30,
                          color: Colors.grey,
                        ),
                        SizedBox(height: 3),
                        Text(
                          "Menu",
                          style: GoogleFonts.poppins(
                            color: Colors.grey,
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                ]),
          ),
        ],
      ),
    );
  }
}
