import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hindishyari/ui/home_page.dart';

class Setting extends StatefulWidget {
  const Setting({super.key});

  @override
  State<Setting> createState() => _SettingState();
}

class _SettingState extends State<Setting> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF430A68),

      body: SafeArea(
        child: Column(
          children: [
            Container(
              height: 55,
              child: Row(
                children: [
                  SizedBox(
                    width: 10,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Icon(
                      color: Colors.white,
                      Icons.arrow_back_outlined,
                      size: 30,
                    ),
                  ),
                  SizedBox(
                    width: 30,
                  ),
                  Expanded(
                    child: Text(
                      "Settings",
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontFamily: 'Poppins_Semibold'),
                    ),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(6),
                child: ListView(
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                          return HomePage();
                        },));
                      },
                      child: Row(
                        children: [
                          SizedBox(width: 10,),
                          Icon(Icons.home,color: Color(0xFFB3AEE8),),
                          SizedBox(width: 20,),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("Home",style: TextStyle(color: Colors.white,fontSize: 14,fontFamily: 'Poppins_Semibold'),),
                                Text("Back To Home",style: TextStyle(color: Color(0xFFB3AEE8),fontSize: 12,fontFamily: 'Poppins_Medium'),),
                              ]
                            ),
                          )
                        ]
                      ),
                    ),
                    SizedBox(height: 30,),
                    Row(
                      children: [
                        SizedBox(width: 10,),
                        Icon(Icons.favorite,color: Color(0xFFB3AEE8),),
                        SizedBox(width: 20,),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Favorites",style: TextStyle(color: Colors.white,fontSize: 14,fontFamily: 'Poppins_Semibold'),),
                              Text("Check favourites list",style: TextStyle(color: Color(0xFFB3AEE8),fontSize: 12,fontFamily: 'Poppins_Medium'),),
                            ]
                          ),
                        )
                      ]
                    ),
                    SizedBox(height: 30,),
                    Row(
                      children: [
                        SizedBox(width: 10,),
                        Icon(Icons.star,color: Color(0xFFB3AEE8),),
                        SizedBox(width: 20,),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Rate Us",style: TextStyle(color: Colors.white,fontSize: 14,fontFamily: 'Poppins_Semibold'),),
                              Text("If you love our app, please take a moment to rate and review it in the Google Play Store",style: TextStyle(color: Color(0xFFB3AEE8),fontSize: 12,fontFamily: 'Poppins_Medium'),),
                            ]
                          ),
                        )
                      ]
                    ),
                    SizedBox(height: 30,),
                    Row(
                      children: [
                        SizedBox(width: 10,),
                        Icon(Icons.share,color: Color(0xFFB3AEE8),),
                        SizedBox(width: 20,),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Share with friends",style: TextStyle(color: Colors.white,fontSize: 14,fontFamily: 'Poppins_Semibold'),),
                              Text("Support us by sharing the app with friends",style: TextStyle(color: Color(0xFFB3AEE8),fontSize: 12,fontFamily: 'Poppins_Medium'),),
                            ]
                          ),
                        )
                      ]
                    ),
                    SizedBox(height: 30,),
                    Row(
                      children: [
                        SizedBox(width: 10,),
                        Icon(Icons.more_horiz_outlined,color: Color(0xFFB3AEE8),),
                        SizedBox(width: 20,),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("More apps",style: TextStyle(color: Colors.white,fontSize: 14,fontFamily: 'Poppins_Semibold'),),
                              Text("If you like the app, don't forget to check out our other apps",style: TextStyle(color: Color(0xFFB3AEE8),fontSize: 12,fontFamily: 'Poppins_Medium'),),
                            ]
                          ),
                        )
                      ]
                    ),
                    SizedBox(height: 30,),
                    Row(
                      children: [
                        SizedBox(width: 10,),
                        Icon(Icons.privacy_tip,color: Color(0xFFB3AEE8),),
                        SizedBox(width: 20,),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Privacy & Policy",style: TextStyle(color: Colors.white,fontSize: 14,fontFamily: 'Poppins_Semibold'),),
                              Text("Read our privacy & policy",style: TextStyle(color: Color(0xFFB3AEE8),fontSize: 12,fontFamily: 'Poppins_Medium'),),
                            ]
                          ),
                        )
                      ]
                    ),
                    SizedBox(height: 30,),
                    Row(
                      children: [
                        SizedBox(width: 10,),
                        Icon(Icons.mobile_friendly,color: Color(0xFFB3AEE8),),
                        SizedBox(width: 20,),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("App Version",style: TextStyle(color: Colors.white,fontSize: 14,fontFamily: 'Poppins_Semibold'),),
                              Text("3.1",style: TextStyle(color: Color(0xFFB3AEE8),fontSize: 12,fontFamily: 'Poppins_Medium'),),
                            ]
                          ),
                        )
                      ]
                    ),
                    SizedBox(height: 30,),
                  ]
                )
              ),
            ),
          ],
        ),
      ),
    );
  }
}
