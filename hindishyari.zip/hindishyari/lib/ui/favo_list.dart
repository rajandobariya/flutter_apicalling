import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FavouriteList extends StatefulWidget {


  @override
  State<FavouriteList> createState() => _FavouriteListState();
}

class _FavouriteListState extends State<FavouriteList> {

  String value = "";

  @override
  void initState() {
    super.initState();
    _loadStoredValue();
  }

  _loadStoredValue() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool isFavorite = prefs.getBool('favorite') ?? false;

    setState(() {
      if (isFavorite) {
        value = prefs.getString('key') ?? "";
      }
      // value = prefs.getString('key') ?? "";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF430A68),
      body: SafeArea(
        child: Column(
          children: [
            Container(
              height: 55,
              child: Row(
                children: [
                  SizedBox(width: 10),
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Icon(
                      Icons.arrow_back_outlined,
                      size: 30,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(width: 30),
                  Expanded(
                    child: Text(
                      "Favourite",
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontFamily: 'Poppins_Semibold'),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(6),
                child: ListView(children: [
                  Text(value,style: TextStyle(color: Colors.white),),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

