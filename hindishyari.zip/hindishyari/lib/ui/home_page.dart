import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hindishyari/ui/ankhen_shayari.dart';
import 'package:hindishyari/ui/setting.dart';
import 'package:share/share.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  var arrData = [
    {
      'img': 'assets/image/ankhe.webp',
      'name': 'Anakhein Shayari',
    },
    {
      'img': 'assets/image/ansoo.webp',
      'name': 'Aansoo Shayari',
    },
    {
      'img': 'assets/image/alone.webp',
      'name': 'Alone Shayari',
    },
    {
      'img': 'assets/image/attitude.webp',
      'name': 'Attitude Shayari',
    },
    {
      'img': 'assets/image/bakwas.webp',
      'name': 'Bakwas Shayari',
    },
    {
      'img': 'assets/image/bewafa.webp',
      'name': 'Bewafa Shayari',
    },
    {
      'img': 'assets/image/birthday.webp',
      'name': 'Birthday Shayari',
    },
    {
      'img': 'assets/image/bollywood.webp',
      'name': 'Bollywood Shayari',
    },
    {
      'img': 'assets/image/broken_heart.webp',
      'name': 'Broken Heart Shayari',
    },
    {
      'img': 'assets/image/chand.webp',
      'name': 'Chand Shayari',
    },
    {
      'img': 'assets/image/cid.webp',
      'name': 'Cid Shayari',
    },
    {
      'img': 'assets/image/dard_bhari.webp',
      'name': 'Dard Bhai Shayari',
    },
    {
      'img': 'assets/image/desh_bhakti.webp',
      'name': 'Desh Bhakti Shayari',
    },
    {
      'img': 'assets/image/dil.webp',
      'name': 'Dill Shayari',
    },
    {
      'img': 'assets/image/dooriyan.webp',
      'name': 'Dooriyan Shayari',
    },
    {
      'img': 'assets/image/dua.webp',
      'name': 'Dua Shayari',
    },
    {
      'img': 'assets/image/friendship.webp',
      'name': 'Friendship Shayari',
    },
    {
      'img': 'assets/image/funny.webp',
      'name': 'Funny Shayari',
    },
    {
      'img': 'assets/image/gham.webp',
      'name': 'Gham Shayari',
    },
    {
      'img': 'assets/image/goodmorning.webp',
      'name': 'Good Morning Shayari',
    },
    {
      'img': 'assets/image/goodnight.webp',
      'name': 'Good Night Shayari',
    },
    {
      'img': 'assets/image/heart_touching.webp',
      'name': 'Heart Touching Shayari',
    },
    {
      'img': 'assets/image/hurt.webp',
      'name': 'Hurt Shayari',
    },
    {
      'img': 'assets/image/inspirational.webp',
      'name': 'Inspiration Shayari',
    },
    {
      'img': 'assets/image/insult.webp',
      'name': 'Insult Shayari',
    },
    {
      'img': 'assets/image/intezaar.webp',
      'name': 'Intezaar Shayari',
    },
    {
      'img': 'assets/image/love.webp',
      'name': 'Love Shayari',
    },
    {
      'img': 'assets/image/maa.webp',
      'name': 'Maa Shayari',
    },
    {
      'img': 'assets/image/mausam.webp',
      'name': 'Mausam Shayari',
    },
    {
      'img': 'assets/image/maut.webp',
      'name': 'Maut Shayari',
    },
    {
      'img': 'assets/image/nafrat.webp',
      'name': 'Nafrat Shayari',
    },
    {
      'img': 'assets/image/romantic.webp',
      'name': 'Romantic Shayari',
    },
    {
      'img': 'assets/image/sad.webp',
      'name': 'Sad Shayari',
    },
    {
      'img': 'assets/image/sharab.webp',
      'name': 'Sharab Shayari',
    },
    {
      'img': 'assets/image/beauty.webp',
      'name': 'Shayari On Beauty',
    },
    {
      'img': 'assets/image/life.webp',
      'name': 'Shayari On Life',
    },
    {
      'img': 'assets/image/sorry.webp',
      'name': 'Sorry Shayari',
    },
    {
      'img': 'assets/image/yaad.webp',
      'name': 'Yaad Shayari',
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF430A68),
      appBar: AppBar(
        backgroundColor: Color(0xFF430A68),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            InkWell(
                onTap: () {
                  SystemNavigator.pop();
                },
                child: Icon(Icons.close, color: Colors.white)),
            SizedBox(
              width: 10,
            ),
            Expanded(
              child: Text(
                'All Shayari',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontFamily: 'Poppins_Semibold',
                ),
              ),
            ),
            SizedBox(
              width: 10,
            ),
            Icon(Icons.favorite, color: Colors.white),
            SizedBox(
              width: 10,
            ),
            InkWell(onTap:() {
              Navigator.push(context,  MaterialPageRoute(builder: (context) {
                return Setting();
              },));
            }, child: Icon(Icons.settings, color: Colors.white)),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(6),
        child: ListView(
          children: arrData
              .map(
                (e) => InkWell(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => AankheinShayari(e['name']),
                        ));
                  },
                  child: Container(
                    padding: EdgeInsets.all(12),
                    margin: EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: Color(0xFF93319E),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(children: [
                      Image.asset('${e['img']}', height: 40, width: 40),
                      SizedBox(
                        width: 10,
                      ),
                      Expanded(
                        child: Text(
                          '${e['name']}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontFamily: 'Poppins_Semibold',
                          ),
                        ),
                      ),
                      Icon(
                        Icons.arrow_forward_ios_outlined,
                        color: Colors.white,
                      )
                    ]),
                  ),
                ),
              )
              .toList(),
        ),
      ),
    );
  }
}
