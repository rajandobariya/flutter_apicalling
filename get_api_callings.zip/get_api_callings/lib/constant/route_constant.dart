class RouteConstant{
  static const String homeScreen = '/home_screen';
}