package com.example.get_api_callings;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
