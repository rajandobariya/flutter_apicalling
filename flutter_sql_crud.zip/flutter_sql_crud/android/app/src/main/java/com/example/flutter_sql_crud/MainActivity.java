package com.example.flutter_sql_crud;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
