class ApiConstant {
  static String baseUrl = "https://jsonplaceholder.typicode.com/photos";
  // static String usersEndpoint = "/photos";
  // static String baseUrl = "https://www.jsonkeeper.com/b/5XYL";
  // static String usersEndpoint = "/photos";
}
