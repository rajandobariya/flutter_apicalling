class Photo{
  String url;
  String text;

  Photo({required this.url,required this.text});
}