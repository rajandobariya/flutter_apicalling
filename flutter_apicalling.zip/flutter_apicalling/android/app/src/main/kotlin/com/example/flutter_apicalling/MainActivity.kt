package com.example.flutter_apicalling

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
